#include "IeumSerializer.h"

namespace Ieum {

namespace {
int currentSchemaVersion() { return 110; } // v1.1.0

juce::String modeToString(IeumBindingMode mode) {
  switch (mode) {
  case IeumBindingMode::Continuous: return "continuous";
  case IeumBindingMode::Toggle:     return "toggle";
  case IeumBindingMode::Trigger:    return "trigger";
  case IeumBindingMode::Relative:   return "relative";
  case IeumBindingMode::Momentary:  return "momentary";
  }
  return "continuous";
}

IeumBindingMode stringToMode(const juce::String &s) {
  if (s == "toggle")    return IeumBindingMode::Toggle;
  if (s == "trigger")   return IeumBindingMode::Trigger;
  if (s == "relative")  return IeumBindingMode::Relative;
  if (s == "momentary") return IeumBindingMode::Momentary;
  return IeumBindingMode::Continuous;
}

juce::var logicSpecToJson(const IeumLogicSpec& logic) {
    juce::DynamicObject::Ptr obj = new juce::DynamicObject();
    juce::String modeStr = "passive";
    switch (logic.mode) {
        case IeumLogicMode::Standard:   modeStr = "standard"; break;
        case IeumLogicMode::Expression: modeStr = "expression"; break;
        case IeumLogicMode::Script:     modeStr = "script"; break;
        default: break;
    }
    obj->setProperty("mode", modeStr);
    obj->setProperty("code", logic.code);
    obj->setProperty("standardMethod", logic.standardMethod);
    obj->setProperty("enabled", logic.enabled);
    return juce::var(obj.get());
}

IeumLogicSpec jsonToLogicSpec(const juce::var& json) {
    if (!json.isObject()) return {};
    IeumLogicSpec logic;
    juce::String modeStr = json.getProperty("mode", "passive").toString();
         if (modeStr == "standard")   logic.mode = IeumLogicMode::Standard;
    else if (modeStr == "expression") logic.mode = IeumLogicMode::Expression;
    else if (modeStr == "script")     logic.mode = IeumLogicMode::Script;
    else                              logic.mode = IeumLogicMode::Passive;
    
    logic.code = json.getProperty("code", "").toString();
    logic.standardMethod = json.getProperty("standardMethod", "").toString();
    logic.enabled = json.getProperty("enabled", true);
    return logic;
}

juce::String typeToString(IeumValueType type) {
  switch (type) {
  case IeumValueType::Floating: return "floating";
  case IeumValueType::Integer:  return "integer";
  case IeumValueType::Boolean:  return "boolean";
  case IeumValueType::Trigger:  return "trigger";
  case IeumValueType::Color:    return "color";
  case IeumValueType::String:   return "string";
  default:                      return "unknown";
  }
}

IeumValueType stringToType(const juce::String &s) {
  if (s == "floating") return IeumValueType::Floating;
  if (s == "integer")  return IeumValueType::Integer;
  if (s == "boolean")  return IeumValueType::Boolean;
  if (s == "trigger")  return IeumValueType::Trigger;
  if (s == "color")    return IeumValueType::Color;
  if (s == "string")   return IeumValueType::String;
  return IeumValueType::Unknown;
}

juce::var rangeToJson(const IeumRange &range) {
  juce::DynamicObject::Ptr obj = new juce::DynamicObject();
  obj->setProperty("min", range.min);
  obj->setProperty("max", range.max);
  return juce::var(obj.get());
}

IeumRange jsonToRange(const juce::var& json) {
    if (!json.isObject()) return { 0.0, 1.0 };
    return { (double)json.getProperty("min", 0.0), (double)json.getProperty("max", 1.0) };
}

juce::var groupToJson(const IeumBindingGroup& group) {
    juce::DynamicObject::Ptr obj = new juce::DynamicObject();
    obj->setProperty("id", group.id);
    obj->setProperty("name", group.name);
    obj->setProperty("enabled", group.enabled);
    obj->setProperty("logic", logicSpecToJson(group.logic));
    
    juce::Array<juce::var> memberIds;
    for (const auto& mid : group.memberIds)
        memberIds.add(mid);
    obj->setProperty("memberIds", memberIds);
    
    return juce::var(obj.get());
}

bool jsonToGroup(IeumBindingGroup& group, const juce::var& json) {
    if (!json.isObject()) return false;
    group.id = json.getProperty("id", "").toString();
    group.name = json.getProperty("name", "").toString();
    group.enabled = json.getProperty("enabled", true);
    group.logic = jsonToLogicSpec(json.getProperty("logic", juce::var()));
    
    group.memberIds.clear();
    const auto* array = json.getProperty("memberIds", juce::var()).getArray();
    if (array != nullptr) {
        for (const auto& mid : *array)
            group.memberIds.push_back(mid.toString());
    }
    return true;
}

} // namespace

juce::var IeumSerializer::toJson(const IeumDocument &doc) {
  juce::DynamicObject::Ptr obj = new juce::DynamicObject();
  obj->setProperty("schemaVersion", currentSchemaVersion());

  juce::Array<juce::var> bindingsArray;
  for (const auto &b : doc.getBindings())
    bindingsArray.add(bindingToJson(b));
  obj->setProperty("bindings", bindingsArray);

  juce::Array<juce::var> groupsArray;
  for (const auto &g : doc.getGroups())
    groupsArray.add(groupToJson(g));
  obj->setProperty("groups", groupsArray);

  return juce::var(obj.get());
}

bool IeumSerializer::fromJson(IeumDocument &doc, const juce::var &json) {
  if (!json.isObject())
    return false;

  doc.clear();
  const auto *bindingsArray = json.getProperty("bindings", juce::var()).getArray();
  if (bindingsArray != nullptr) {
    for (const auto &bVar : *bindingsArray) {
      IeumBindingSpec spec;
      if (jsonToBinding(spec, bVar))
        doc.addBinding(spec);
    }
  }

  const auto *groupsArray = json.getProperty("groups", juce::var()).getArray();
  if (groupsArray != nullptr) {
    for (const auto &gVar : *groupsArray) {
      IeumBindingGroup group;
      if (jsonToGroup(group, gVar))
        doc.addGroup(group);
    }
  }

  return true;
}

juce::var IeumSerializer::bindingToJson(const IeumBindingSpec &spec) {
  juce::DynamicObject::Ptr obj = new juce::DynamicObject();
  obj->setProperty("id", spec.id);
  obj->setProperty("name", spec.name);
  obj->setProperty("enabled", spec.enabled);
  obj->setProperty("mode", modeToString(spec.mode));
  obj->setProperty("valueType", typeToString(spec.valueType));
  obj->setProperty("transformId", spec.transformId.toString());

  obj->setProperty("source", endpointToJson(spec.source));
  obj->setProperty("target", endpointToJson(spec.target));
  
  obj->setProperty("groupId", spec.groupId);
  obj->setProperty("priority", spec.priority);
  obj->setProperty("logic", logicSpecToJson(spec.logic));
  obj->setProperty("sourceRange", rangeToJson(spec.sourceRange));
  obj->setProperty("targetRange", rangeToJson(spec.targetRange));

  return juce::var(obj.get());
}

juce::var IeumSerializer::endpointToJson(const IeumEndpoint &endpoint) {
  juce::DynamicObject::Ptr obj = new juce::DynamicObject();
  obj->setProperty("providerId", endpoint.providerId.toString());
  obj->setProperty("entityId", endpoint.entityId);
  obj->setProperty("paramId", endpoint.paramId);
  return juce::var(obj.get());
}

bool IeumSerializer::jsonToBinding(IeumBindingSpec &spec, const juce::var &json) {
  if (!json.isObject())
    return false;

  spec.id = json.getProperty("id", "").toString();
  spec.name = json.getProperty("name", "").toString();
  spec.enabled = json.getProperty("enabled", true);
  spec.mode = stringToMode(json.getProperty("mode", "").toString());
  spec.valueType = stringToType(json.getProperty("valueType", "").toString());
  spec.transformId = json.getProperty("transformId", "").toString();

  jsonToEndpoint(spec.source, json.getProperty("source", juce::var()));
  jsonToEndpoint(spec.target, json.getProperty("target", juce::var()));
  
  spec.groupId = json.getProperty("groupId", "").toString();
  spec.priority = json.getProperty("priority", 0);
  spec.logic = jsonToLogicSpec(json.getProperty("logic", juce::var()));
  spec.sourceRange = jsonToRange(json.getProperty("sourceRange", juce::var()));
  spec.targetRange = jsonToRange(json.getProperty("targetRange", juce::var()));

  return true;
}

bool IeumSerializer::jsonToEndpoint(IeumEndpoint &endpoint, const juce::var &json) {
  if (!json.isObject())
    return false;
  endpoint.providerId = json.getProperty("providerId", "").toString();
  endpoint.entityId = json.getProperty("entityId", "").toString();
  endpoint.paramId = json.getProperty("paramId", "").toString();
  return true;
}

} // namespace Ieum
