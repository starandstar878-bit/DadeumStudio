#pragma once

#include "Gyeol/Editor/Theme/GyeolCustomLookAndFeel.h"
#include "Gyeol/Widgets/WidgetSDK.h"

namespace Gyeol::Widgets {
class ButtonWidget final : public WidgetClass {
public:
  WidgetDescriptor makeDescriptor() const override {
    WidgetDescriptor descriptor;
    descriptor.type = WidgetType::button;
    descriptor.typeKey = "button";
    descriptor.displayName = "Button";
    descriptor.category = "Control";
    descriptor.tags = {"button", "trigger", "click"};
    descriptor.iconKey = "button";
    descriptor.exportTargetType = "juce::TextButton";
    descriptor.defaultBounds = {0.0f, 0.0f, 96.0f, 30.0f};
    descriptor.minSize = {48.0f, 24.0f};
    applyBuiltinDescriptorDefaults(descriptor, "button", "widget.button.label");
    descriptor.capabilities = {"emitsRuntimeEvents", "acceptsAssetDrop"};
    descriptor.supportsOffscreenCache = true;
    descriptor.estimatedPaintCost = 0.12;
    descriptor.memoryBudgetKb = 64;
    descriptor.supportedActions = {"setRuntimeParam", "adjustRuntimeParam",
                                   "toggleRuntimeParam", "setNodeProps",
                                   "setNodeBounds"};
    descriptor.stateOutputs = {"pressed"};
    descriptor.defaultProperties.set("text", juce::String("Button"));
    descriptor.runtimeEvents = {
        {"onClick", "Click", "Fires when the button is clicked", false},
        {"onPress", "Press", "Fires when mouse/touch is pressed", false},
        {"onRelease", "Release", "Fires when mouse/touch is released", false}};
    for (auto &eventSpec : descriptor.runtimeEvents)
      eventSpec.payloadSchema = makePayloadSchema();
    {
      WidgetPropertySpec textSpec;
      textSpec.key = juce::Identifier("text");
      textSpec.label = "Text";
      textSpec.kind = WidgetPropertyKind::text;
      textSpec.uiHint = WidgetPropertyUiHint::lineEdit;
      textSpec.group = "Content";
      textSpec.order = 10;
      textSpec.hint = "Button caption text";
      textSpec.defaultValue = juce::var("Button");
      textSpec.required = true;
      textSpec.maxLength = 128;
      descriptor.propertySpecs.push_back(std::move(textSpec));

      WidgetPropertySpec bgImageSpec;
      bgImageSpec.key = juce::Identifier("button.backgroundImage");
      bgImageSpec.label = "Background Image";
      bgImageSpec.kind = WidgetPropertyKind::assetRef;
      bgImageSpec.uiHint = WidgetPropertyUiHint::assetPicker;
      bgImageSpec.group = "Appearance";
      bgImageSpec.order = 100;
      bgImageSpec.hint = "Optional image asset id for button body";
      bgImageSpec.acceptedAssetKinds = {AssetKind::image};
      bgImageSpec.acceptedMimeTypes = {"image/png", "image/jpeg", "image/webp"};
      bgImageSpec.maxAssetBytes = 8 * 1024 * 1024;
      bgImageSpec.advanced = false;
      descriptor.propertySpecs.push_back(std::move(bgImageSpec));

      WidgetPropertySpec iconImageSpec;
      iconImageSpec.key = juce::Identifier("button.iconImage");
      iconImageSpec.label = "Icon Image";
      iconImageSpec.kind = WidgetPropertyKind::assetRef;
      iconImageSpec.uiHint = WidgetPropertyUiHint::assetPicker;
      iconImageSpec.group = "Appearance";
      iconImageSpec.order = 110;
      iconImageSpec.hint = "Optional image asset id for icon";
      iconImageSpec.acceptedAssetKinds = {AssetKind::image};
      iconImageSpec.acceptedMimeTypes = {"image/png", "image/jpeg", "image/webp"};
      iconImageSpec.maxAssetBytes = 8 * 1024 * 1024;
      iconImageSpec.advanced = true;
      descriptor.propertySpecs.push_back(std::move(iconImageSpec));
    }
    descriptor.painter = [](juce::Graphics &g, const WidgetModel &widget,
                            const juce::Rectangle<float> &body) {
      g.setColour(Gyeol::getGyeolColor(Gyeol::GyeolPalette::ControlBase));
      g.fillRoundedRectangle(body, 6.0f);
      g.setColour(Gyeol::getGyeolColor(Gyeol::GyeolPalette::TextPrimary));
      g.setFont(juce::FontOptions(12.0f, juce::Font::bold));
      const auto text =
          widget.properties.getWithDefault("text", juce::var("Button"))
              .toString();
      g.drawFittedText(text.isEmpty() ? "Button" : text, body.toNearestInt(),
                       juce::Justification::centred, 1);
    };
    descriptor.iconPainter = [](juce::Graphics &g,
                                const juce::Rectangle<float> &r) {
      g.setColour(Gyeol::getGyeolColor(Gyeol::GyeolPalette::BorderActive));
      g.fillRoundedRectangle(r.reduced(6.0f, 10.0f), 4.0f);
    };
    descriptor.cursorProvider = [](const WidgetModel &, juce::Point<float>) {
      return juce::MouseCursor(juce::MouseCursor::PointingHandCursor);
    };
    descriptor.dropOptions = [](const WidgetModel &, const AssetRef &asset) {
      if (!asset.mime.startsWithIgnoreCase("image/"))
        return std::vector<DropOption>{};

      return std::vector<DropOption>{
          {"Button Background", juce::Identifier("button.backgroundImage"),
           "Apply image to button body"},
          {"Button Icon", juce::Identifier("button.iconImage"),
           "Apply image as button icon"}};
    };
    descriptor.applyDrop = [](PropertyBag &patchOut, const WidgetModel &,
                              const AssetRef &asset, const DropOption &option) {
      patchOut.set(option.propKey, asset.assetId);
      return juce::Result::ok();
    };
    return descriptor;
  }
};

GYEOL_WIDGET_AUTOREGISTER(ButtonWidget);
} // namespace Gyeol::Widgets
