# Teul (틀) — UI/UX 로드맵
> DSP 그래프 에디터의 시각적 경험 목표: 노드들이 살아 숨쉬고, 신호의 흐름이 눈에 보이는 프로페셔널 그래프 캔버스 구축.

---

> [!TIP]
> **개발 사이클 전략**: UI Phase 완료 후에는 바로 다음 UI Phase로 넘어가지 말고,
> 아래 **`→ 기능 로드맵 복귀`** 마커가 표시된 시점에 [Teul Roadmap.md](Teul%20Roadmap.md)의
> 해당 Phase로 복귀하여 기능 구현 후 다음 UI Phase로 진행하세요.

---

## Phase 1: 그래프 캔버스 쉘 (Canvas Shell)

### 목표
- 인피니트 패닝/줌이 가능한 노드 그래프 캔버스 기반을 구축한다.

### 구현 단계

#### 단계 1: 그래프 캔버스 기반
- [x] **`TGraphCanvas` 컴포넌트 구축**: Gyeol의 `CanvasComponent`에서 검증된 월드↔뷰 좌표계(Zoom/Pan) 구조를 Teul용으로 독립 재구현
- [x] **인피니트 그리드 배경**: 마우스 휠 줌 배율에 따라 도트 또는 격자선이 자연스럽게 스케일되는 배경 렌더링 (LOD 기법 적용)
- [x] **Pan 단축키**: `Space + 드래그` or `마우스 휠` 로 캔버스 이동

#### 단계 2: 현대적 UI 쉘
- [x] **다크 테마 전용 팔레트**: `GyeolPalette`와 구분되는 Teul 전용 칩(dark charcoal) 배경 + 포트 타입별 엑센트 컬러 정의
- [x] **안티앨리어싱 캔버스 외각선**: 노드 컴포넌트의 모서리를 4~8px 라운드 처리, 연결선(Wire)은 2px 베지어 곡선으로 렌더
- [x] **줌 레벨 인디케이터**: 우하단에 현재 배율을 표시하는 미니 HUD 레이블 (예: `125%`)

---

> **→ 기능 로드맵 복귀**: `UI Phase 1` 완료 후 **[기능 Phase 2: 노드 레지스트리 및 팩토리](Teul%20Roadmap.md)** 로 복귀하세요.
> 캔버스 위에 실제로 그릴 노드 타입·포트 정보가 필요하므로, 기능 레지스트리를 먼저 완성한 뒤 UI Phase 2로 넘어오세요.

---

## Phase 2: 노드 컴포넌트 렌더링 (Node Renderer)

### 목표
- 개별 노드를 직관적이고 아름답게 렌더링한다.

### 구현 단계

#### 단계 1: 노드 바디 렌더링
- [x] **노드 기본 레이아웃**: 상단 헤더(배경색 + 타입명 + 활성/바이패스 토글) + 중단 포트 영역 + 하단 파라미터 영역으로 구성된 3단 레이아웃
- [x] **포트 타입별 색상 시스템**:
  - `Audio` → 초록(Green)
  - `CV (Control Voltage)` → 노란(Amber)
  - `MIDI` → 파랑(Blue)
  - `Control` → 보라(Purple)
- [x] **선택 하이라이트**: 선택 시 노드 외곽선에 흰색 1.5px 테두리 + 미약한 `DropShadow` glow 효과

#### 단계 2: 고급 노드 상태 표현
- [x] **바이패스(Bypass) 모드**: 활성화 시 노드가 희미하게(투명도 40%) 표시되고, 신호가 바이패스 됨을 직관적으로 전달
- [x] **에러/경고 배지**: 연결이 잘못되었거나 파라미터 값이 범위를 벗어났을 때 노드 우상단에 ⚠️ 마이크로 펄스(Pulse) 배지 표시
- [x] **미니마이즈(Collapse) 토글**: 노드를 헤더 높이로 접어 캔버스를 깔끔하게 정리하는 토글 버튼

#### 단계 3: 내장 노드 전용 비주얼
- [x] **오실레이터 파형 프리뷰**: 오실레이터 노드 바디 안에 현재 파형 모양을 실시간으로 렌더링하는 미니 `Path` 시각화
- [x] **ADSR 커브 프리뷰**: ADSR 노드 안에 현재 파라미터에 맞는 어택/디케이/서스테인/릴리스 곡선을 인라인 미니 차트로 표시
- [x] **레벨 미터**: Gain/Mixer 노드에서 현재 오디오 레벨을 `fillRect` 기반 실시간 스펙트럼 바로 표시

---

> **→ 기능 로드맵 복귀**: `UI Phase 2` 완료 후 **[기능 Phase 3: 오디오 런타임 엔진](Teul%20Roadmap.md)** 으로 복귀하세요.
> 노드 렌더링이 완성된 지금, 런타임 엔진을 구현해 실제 신호가 흐르는 상태를 만든 뒤 UI Phase 3(연결선 시각화)로 넘어오세요.

---

## Phase 3: 연결선(Wire) 렌더링 시스템 (Connection Visuals)

### 목표
- 사용자가 신호의 흐름을 한눈에 파악할 수 있도록 연결선을 아름답고 명확하게 렌더링한다.

### 구현 단계

#### 단계 1: 베지어 케이블 렌더링
- [x] **수평 탄젠트 베지어 곡선**: 출력 포트에서 입력 포트까지 `juce::Path`의 `cubicTo()`를 이용한 S자형 곡선 렌더링
- [x] **포트 타입 연동 색상**: 연결선 색상은 소스 포트의 타입 색상을 그대로 상속 (Audio=초록, CV=노란 등)
- [x] **연결선 두께 및 투명도**: 기본 2px, 선택 시 3px + 살짝 더 밝게. 비선택 상태에서는 alpha 75%로 오버라이드

#### 단계 2: 인터랙티브 연결 드로잉
- [x] **드래그 연결 생성**: 출력 포트를 드래그하면 마우스를 따라오는 임시 연결선(Dotted) 렌더링. 호환되는 입력 포트 위에 마우스를 올리면 포트가 강조됨(Glow)
- [x] **타입 불일치 피드백**: 드래그 중 현재 마우스 아래 포트가 타입이 다를 경우, 임시 케이블이 붉은색으로 전환되어 연결 불가 시각 피드백 제공
- [x] **연결 끊기(Disconnect)**: 연결선을 `Alt + 클릭` 또는 중간 지점을 드래그하면 연결 분리, 분리된 선 끝에서 케이블이 중력처럼 축 늘어지는 미니 Fade-out 애니메이션

#### 단계 3: 신호 흐름 애니메이션 (선택적)
- [x] **플로우 애니메이션**: Run 모드에서 연결선 위를 밝은 점(Pulse)이 출력→입력 방향으로 흘러가는 마치 전류가 흐르는 듯한 실시간 애니메이션
- [x] **레벨 반응형 케이블 밝기**: 해당 연결에 흐르는 오디오 신호의 레벨에 따라 케이블의 밝기(alpha)가 실시간으로 미세하게 변동

---

> **→ 기능 로드맵 복귀**: `UI Phase 3` 완료 후 **[기능 Phase 4: Ieum 파라미터 브리지 연동](Teul%20Roadmap.md)** 으로 복귀하세요.
> 연결선 비주얼이 완성된 지금 Ieum 인터페이스를 구현해 파라미터 표면을 노출한 뒤 UI Phase 4(UX 인터랙션)로 넘어오세요.

---

## Phase 4: UX 인터랙션 및 생산성 (Editor UX)

### 목표
- 노드를 빠르고 직관적으로 배치하고 탐색할 수 있는 환경을 제공한다.

### 구현 단계

#### 단계 1: 빠른 추가(Quick Add) 고도화
- [x] **빠른 추가 팝업 (Quick Add)**: 캔버스 빈 곳에서 더블클릭하면 노드 검색 팝업 등장. 타이핑으로 필터링 후 엔터로 즉시 해당 위치에 노드 배치
- [x] **퍼지 검색 + 최근 사용 우선**: 완전 일치가 아니어도 결과를 찾고, 최근 삽입한 노드를 상단에 우선 노출
- [x] **키보드 완결 플로우**: `Tab`, `↑/↓`, `Enter`, `Esc`만으로 탐색/삽입/취소 가능

#### 단계 2: 노드 라이브러리 & 삽입 배치
- [x] **노드 라이브러리 사이드 패널**: 좌측에 카테고리별(소스, 필터, 믹서, 유틸) 노드 목록 패널. 드래그 앤 드롭으로 캔버스에 배치
- [x] **와이어 위 삽입(Insert on Wire)**: 노드를 연결선 위에 드롭하면 기존 연결을 분할하여 자동으로 앞/뒤 재연결
- [x] **캔버스 우클릭 추가 메뉴**: '여기에 노드 추가' 리스트 + 현재 위치 기준 즉시 생성

#### 단계 3: 멀티 셀렉션 및 정렬 도구
- [x] **마키 선택 (Marquee)**: 드래그로 직사각형을 그려 범위 내 노드 다중 선택 후 정렬·그룹화 가능
- [x] **정렬/간격 분배 (Align/Distribute)**: 좌/우/상/하 정렬과 일정 간격 분배를 원클릭 제공
- [x] **스마트 스냅 가이드**: 이동 중 중심선/간격 스냅과 가이드 라인 표시

#### 단계 4: 미니맵 및 대형 그래프 내비게이션
- [x] **Mini-Map Navigator**: Gyeol 네비게이터 패널과 동일한 개념의 그래프 전체 미니맵을 우하단에 표시
- [x] **미니맵 클릭 점프 + 뷰포트 드래그**: 미니맵에서 클릭하면 해당 위치로 이동하고, 뷰 박스를 직접 드래그해 탐색
- [x] **노드 검색 점프**: 노드 이름 검색 후 해당 노드로 카메라를 즉시 포커싱

#### 단계 5: 맥락 메뉴(Context Menu) 확장
- [x] **노드 우클릭 메뉴**: 복제(Duplicate), 삭제, 바이패스 토글, 연결 모두 끊기(Disconnect All), 속성 패널 열기
- [x] **노드 교체(Replace Node)**: 타입 호환 가능한 다른 노드로 교체하고 가능한 연결/파라미터를 유지
- [x] **멀티 선택 일괄 명령**: 다중 선택 상태에서 일괄 바이패스, 일괄 복제, 일괄 삭제 지원

#### 단계 6: 그래프 구조화(Organization)
- [x] **코멘트/프레임 영역**: 여러 노드를 시각적 프레임으로 묶어 패치 의도를 문서화
- [x] **프레임 접기/잠금**: 큰 패치를 접어서 단순화하고 실수 이동을 방지
- [x] **색상 태그/북마크**: 중요 서브그래프를 색상/북마크로 빠르게 탐색

#### 단계 7: 파워 유저 워크플로우
- [x] **커맨드 팔레트(Command Palette)**: 기능 검색 후 즉시 실행
- [x] **단축키 중심 편집**: 노드 추가/정렬/연결 해제 등 주요 동작의 단축키 제공
- [x] **안전 장치 UX**: 위험 동작(대량 삭제/해제) 전 확인 및 즉시 Undo 안내

---

> **→ 기능 로드맵 복귀**: `UI Phase 4` 완료 후 **[기능 Phase 5: Export (C++ 코드 생성)](Teul%20Roadmap.md)** 으로 복귀하세요.
> UX 인터랙션이 갖춰진 지금 Export 기능을 구현한 뒤 UI Phase 5(파라미터 편집 패널)로 넘어오세요.

---

## Phase 5: 파라미터 편집 패널 (Property Panel)

### 목표
- 선택된 노드의 파라미터를 직관적으로 편집하는 전용 사이드 패널을 제공한다.

### 구현 단계

- [x] **노드 선택 연동**: 노드 클릭 시 우측 Property 패널에 해당 노드의 파라미터 에디터가 자동 전환
- [x] **파라미터 위젯 자동 생성**: 파라미터 타입에 따라 슬라이더(Float), 콤보박스(Enum), 토글(Bool), 텍스트필드(String) 자동 생성
- [x] **Ieum 연동 표시**: 특정 파라미터가 Ieum을 통해 Gyeol UI에 이미 바인딩된 경우, 해당 파라미터 행에 🔗 아이콘과 연결된 Gyeol 위젯 이름을 표시
- [x] **실시간 값 피드백**: Run 모드에서 오디오 스레드가 갱신하는 현재 값을 30fps 이하의 안전한 타이머로 폴링해 UI에 반영

---

> **→ 기능 로드맵 복귀**: `UI Phase 5` 완료 후 **[기능 Phase 6: Runtime Hardening & Real-time Safety](Teul%20Roadmap.md)** 으로 복귀하세요.
> Property Panel과 export 기반이 마련된 지금부터는 "보기 좋은 편집기"보다 "실전에서 안전하게 돌고, 문제를 빨리 찾고, 배포 가능한가"를 UI가 뒷받침해야 합니다.

---

## Phase 6: 런타임 상태/안전성 UX (Runtime Safety UX)

### 목표
- Run 모드에서 그래프 상태, 성능 여유, 재빌드 위험도를 즉시 파악하고, 안전하지 않은 편집은 예측 가능하게 제어한다.

### 구현 단계

#### 단계 1: 런타임 상태 HUD
- [x] **세션 상태 바**: sample rate, block size, channel layout, CPU load, rebuild pending, bypass 상태를 상단 HUD에 집계
- [x] **오디오 상태 배지**: xrun, clip, denormal, muted fallback 같은 런타임 이상 상태를 색상 배지와 짧은 원인 텍스트로 표시
- [x] **실행 모드 전환 피드백**: Stop/Preview/Run 전환 시 prepare/rebuild/reset이 언제 발생하는지 사용자에게 명확히 안내

#### 단계 2: 안전한 편집 피드백
- [x] **deferred apply 배너**: 오디오 재구성이 필요한 변경은 즉시 적용 대신 안전 지점에서 반영된다는 배너/큐 UI 제공
- [x] **파라미터 smoothing 시각화**: smoothing, bypass fade, snap-to-step 같은 동작이 UI에서 예측 가능하게 보이도록 표시
- [x] **위험 동작 가드**: Run 중 asset 교체, channel layout 변경, 대규모 삭제 같은 고위험 동작에 경고와 복구 경로 제공

#### 단계 3: 성능/핫스팟 가시화
- [x] **노드 비용 heatmap**: CPU 사용량이 큰 노드나 병목 경로를 canvas 위 heatmap/outline으로 표시
- [x] **버퍼/스케줄 오버레이**: export/runtime 스케줄과 임시 버퍼 사용량을 시각적으로 탐색하는 디버그 오버레이 제공
- [x] **라이브 프로브**: wire/노드 위에 레벨, CV 값, gate 상태를 가볍게 찍어볼 수 있는 probe 모드 제공

---

> **→ 기능 로드맵 복귀**: `UI Phase 6` 완료 후 **[기능 Phase 7: Verification & Benchmark Infrastructure](Teul%20Roadmap.md)** 로 복귀하세요.
> 이제부터는 안전성 감각이 아니라 검증 가능성이 중요합니다. 오류와 성능 회귀를 UI에서 빠르게 파악할 수 있어야 합니다.

---

## Phase 7: 검증/진단 워크스페이스 (Verification Workspace)

### 목표
- validation, export report, parity test, benchmark 결과를 사람이 빠르게 읽고 원인까지 추적할 수 있는 전용 진단 화면을 만든다.

### Current Status
- [x] Diagnostics Drawer baseline and toolbar entry point
- [x] Latest parity/stress/benchmark/compile artifact summaries
- [ ] Severity filters and node/connection focus jump
- [ ] runtime/export compare screen, benchmark timeline, one-click action bar

### 구현 단계

#### 단계 1: 진단 패널
- [x] **Diagnostics Drawer**: toolbar entry point and bottom drawer for latest parity/matrix/stress/benchmark/compile artifact summaries
- [ ] **문제 원인 카드**: 누락 자산, 지원 불가 노드, 타입 불일치, export 제한 사항을 해결 액션과 함께 카드 형태로 제시
- [ ] **report diff 뷰**: 현재 문서와 직전 validation/export 결과의 차이를 비교 표시

#### 단계 2: 검증 결과 비교
- [ ] **runtime vs export 비교 화면**: parity pass/fail, tolerance, 샘플 차이, 스냅샷 링크를 한 화면에 집계
- [ ] **benchmark 타임라인**: 대표 그래프별 CPU/rebuild/export 시간 추세를 저장하고 회귀를 시각화
- [x] **smoke/export artifact viewer**: Diagnostics Drawer shows latest compile/parity/stress/benchmark artifact paths and summaries

#### 단계 3: 테스트 조작 UX
- [ ] **one-click validate/export/benchmark**: 에디터 내부에서 주요 검증 작업을 즉시 실행하는 액션 바 제공
- [ ] **대표 그래프 세트 관리**: golden test/benchmark에 쓰는 문서를 태그와 함께 관리
- [ ] **결과 공유 포맷**: 로그/JSON/report를 팀원에게 전달하기 쉬운 요약 복사 기능 제공

---

> **→ 기능 로드맵 복귀**: `UI Phase 7` 완료 후 **[기능 Phase 8: Preset, State & Compatibility](Teul%20Roadmap.md)** 로 복귀하세요.
> 검증 환경이 생기면 이제 사용자의 작업물 자체를 안전하게 저장하고 복구하는 UX가 필요합니다.

---

## Phase 8: 프리셋/상태/복구 UX (Preset & Recovery UX)

### 목표
- 문서, 프리셋, 자동 저장 상태를 잃지 않고 다루며, 버전 차이와 충돌 상황도 사용자가 이해 가능한 흐름으로 안내한다.

### 구현 단계

#### 단계 1: 프리셋 브라우저
- [ ] **Preset Browser**: 태그, 즐겨찾기, 최근 사용, 미리듣기 메타데이터를 포함한 프리셋 탐색 패널
- [ ] **노드 상태 스냅샷**: 전체 그래프뿐 아니라 선택 노드/서브그래프 단위 preset 저장과 recall 지원
- [ ] **변경 비교 보기**: 현재 상태와 저장된 프리셋 간 차이를 항목별로 보여주는 diff 뷰 제공

#### 단계 2: 저장/복구 흐름
- [ ] **dirty state 표시**: 문서 제목, 탭, 패널에 저장 여부와 마지막 autosave 시점을 일관되게 표시
- [ ] **crash recovery 대화상자**: 비정상 종료 후 복구 가능한 autosave 후보와 차이 요약을 제시
- [ ] **충돌 해결 흐름**: 외부 수정, import 병합, 버전 충돌 시 선택 가능한 복구 경로 제공

#### 단계 3: External Control Source Rail UX
- [ ] **Input/Output/Control rail 레이아웃**: 좌측 Input rail, 우측 Output rail, 하단 Control Source rail을 고정 영역으로 두고 일반 캔버스 노드와 역할을 분리
- [ ] **동적 장치 감지**: 연결된 MIDI foot controller, expression pedal, switch 입력을 감지해 rail 안에 임시 source로 자동 생성
- [ ] **learn + confirm 플로우**: 사용자가 페달을 움직이거나 스위치를 눌러 `EXP 1`, `FS 1` 같은 source를 확정하고 이름, 타입, momentary/toggle 모드를 보정
- [ ] **device profile persist**: 장치별 source 구성, 표시 이름, 바인딩, rail 배치를 profile로 저장하고 재연결 시 복원
- [ ] **assignment inspector**: rail source를 선택하면 현재 바인딩 대상, 출력 포트(`Value`, `Gate`, `Trigger`), 장치 원본 CC/Note 정보를 inspector에서 편집
- [ ] **rail collapse / density 제어**: 장치 수가 많아도 중앙 캔버스를 압박하지 않도록 compact, collapse, group-by-device 표시를 지원

#### 단계 4: 호환성 안내 UX
- [ ] **migration 경고 배너**: 구버전 문서/프리셋을 열 때 변환 항목과 잠재적 손실을 미리 안내
- [ ] **deprecated/alias 표시**: 대체 노드, renamed param, 호환성 shim 사용 여부를 명시적으로 노출
- [ ] **복구 가능성 등급**: 완전 복구/부분 복구/수동 조치 필요를 문서 단위 배지로 표시

---

> **→ 기능 로드맵 복귀**: `UI Phase 8` 완료 후 **[기능 Phase 9: Asset & Dependency Packaging](Teul%20Roadmap.md)** 로 복귀하세요.
> 이제부터는 문서 내부만이 아니라 외부 자산까지 포함한 프로젝트 이동성과 복구 경험을 설계해야 합니다.

---

## Phase 9: 자산/패키징 UX (Asset & Packaging UX)

### 목표
- 샘플, impulse, wavetable 같은 외부 자산이 있는 그래프도 사용자가 누락 없이 추적하고 패키징할 수 있게 한다.

### 구현 단계

#### 단계 1: 자산 브라우저
- [ ] **Asset Browser**: 문서가 참조하는 모든 외부 파일을 타입, 경로, 크기, 사용 노드 기준으로 탐색
- [ ] **의존성 맵**: 어떤 노드가 어떤 자산을 참조하는지 그래프/리스트 양쪽에서 표시
- [ ] **unused/missing 표시**: 누락 자산, 중복 자산, 더 이상 쓰이지 않는 자산을 명확히 구분

#### 단계 2: relink/복구 흐름
- [ ] **Missing Asset Wizard**: 누락 파일을 폴더 스캔, 최근 경로, 수동 지정으로 재연결하는 단계형 UI 제공
- [ ] **정책 선택 UI**: copy into package, relative path 유지, external reference 유지 정책을 자산별/문서별로 선택
- [ ] **복구 로그**: 어떤 자산이 어디로 치환됐는지 추적 가능한 변경 이력 제공

#### 단계 3: 패키지 미리보기
- [ ] **Package Preview**: export 전에 포함 파일 목록, 예상 폴더 구조, 총 용량, 누락 리스크를 요약
- [ ] **portable health check**: 다른 머신에서 깨질 가능성이 있는 절대 경로/외부 참조를 경고
- [ ] **README/manifest 미리보기**: 함께 생성될 문서와 manifest 내용을 UI에서 검토 가능하게 제공

---

> **→ 기능 로드맵 복귀**: `UI Phase 9` 완료 후 **[기능 Phase 10: Product Integration & Host Templates](Teul%20Roadmap.md)** 로 복귀하세요.
> 패키징이 정리되면 사용자가 generated 결과물을 실제 제품 프로젝트에 붙이는 마지막 경험을 다듬어야 합니다.

---

## Phase 10: Export 통합/호스트 셋업 UX (Integration UX)

### 목표
- export 결과를 앱/플러그인/호스트 프로젝트에 가져다 붙이는 과정을 마법사 수준으로 단순화한다.

### 구현 단계

#### 단계 1: Export Wizard
- [ ] **모드별 export 마법사**: EditableGraph, RuntimeModule, dry-run을 선택하고 출력 경로/클래스명/템플릿을 한 번에 설정
- [ ] **사전 검증 요약**: export 직전에 실패 가능성, 누락 자산, 생성 파일 수를 체크리스트로 요약
- [ ] **산출물 요약 화면**: 생성된 `.h/.cpp`, manifest, asset folder, build snippet을 카드 형태로 정리

#### 단계 2: 통합 안내 UX
- [ ] **호스트 템플릿 런처**: standalone app, AudioProcessor, 테스트 호스트용 예제 템플릿을 바로 여는 진입점 제공
- [ ] **Projucer/CMake 편입 가이드**: 현재 export 결과를 어떤 파일에 어떻게 포함해야 하는지 단계별 안내
- [ ] **파라미터 매핑 미리보기**: APVTS/Ieum에 노출되는 파라미터 표면을 export 전에 검토 가능하게 표시

#### 단계 3: 사후 검증/지원
- [ ] **post-export smoke 버튼**: 생성 직후 smoke validate/compile을 실행하고 결과를 요약 표시
- [ ] **integration checklist**: prepare/process, bus layout, latency, tail 등 빠뜨리기 쉬운 항목을 체크리스트화
- [ ] **copy-ready snippet**: 문서/프로젝트에 붙일 include, registration, attachment 코드를 복사 가능한 형태로 제공

---

> **→ 기능 로드맵 복귀**: `UI Phase 10` 완료 후 **[기능 Phase 11: Tooling, CLI & Team Workflow](Teul%20Roadmap.md)** 로 복귀하세요.
> 이제 단일 사용자 편집기를 넘어 팀과 CI가 같은 결과를 보게 만드는 운영 UX가 필요합니다.

---

## Phase 11: 팀 워크플로우/자동화 UX (Team Workflow UX)

### 목표
- 로컬 편집기, CLI, CI 결과가 서로 끊기지 않고 이어지며, 팀 단위 리뷰와 재현이 쉬운 운영 화면을 제공한다.

### 구현 단계

#### 단계 1: 작업 실행 허브
- [ ] **작업 센터(Task Center)**: validate, export, benchmark, package 작업의 큐/진행률/최근 결과를 한 화면에 집계
- [ ] **프로필 저장**: 자주 쓰는 export/benchmark 설정을 preset처럼 저장하고 재실행
- [ ] **배치 액션**: 여러 문서를 연속 검증하거나 export하는 대량 작업 UI 제공

#### 단계 2: 리포트/재현 UX
- [ ] **JSON report 뷰어**: machine-readable report를 사람이 읽기 쉬운 표/트리로 시각화
- [ ] **실행 이력 비교**: 같은 문서의 서로 다른 실행 결과를 diff 형태로 비교
- [ ] **재현 패키지 생성**: 버그 보고용 문서, 로그, 설정, asset manifest를 묶는 repro bundle 생성 UI 제공

#### 단계 3: 팀 온보딩/레퍼런스
- [ ] **cookbook 브라우저**: 대표 그래프, 패턴, 권장 연결 예제를 카테고리로 탐색
- [ ] **규약 체크 배지**: 팀이 정한 export naming, asset policy, validation 기준 위반 여부를 즉시 표시
- [ ] **리뷰용 요약 패널**: 현재 문서의 노드 수, exposed param 수, 외부 자산 수, export 위험도를 한 번에 보여주는 리뷰 패널 제공

---

> **→ 기능 로드맵 복귀**: `UI Phase 11` 완료 후 **[기능 Phase 12: Commercial Release Readiness](Teul%20Roadmap.md)** 로 복귀하세요.
> 이제 마지막 단계는 기능 추가가 아니라 상용 릴리스에서 문제를 줄이는 마감 품질입니다.

---

## Phase 12: 릴리스 폴리시/상용 완성도 UX (Commercial UX)

### 목표
- 첫 실행부터 오류 대응, 접근성, 지원 번들까지 포함해 실제 고객이 매일 써도 버틸 수 있는 제품 경험으로 마무리한다.

### 구현 단계

#### 단계 1: 접근성/기본 품질
- [ ] **키보드 완전 탐색**: canvas 이동, 노드 선택, 포트 연결, panel 탐색까지 마우스 없이 가능한 경로 확보
- [ ] **고대비/색각 보정 테마**: 포트 타입 색상과 상태 배지가 색각 다양성에서도 구분되도록 대체 테마 제공
- [ ] **배율/해상도 적응성**: 100%~200% 이상 배율, 작은 노트북 화면, 고해상도 모니터에서 레이아웃 안정화

#### 단계 2: 온보딩/문서 진입
- [ ] **first-run onboarding**: 첫 그래프 생성, 노드 연결, 소리 출력, export까지 이어지는 단계형 튜토리얼 제공
- [ ] **빈 상태/실패 상태 문구 정비**: 아무 것도 없는 상태, 누락 자산, export 실패, 복구 실패 화면을 제품 수준 문구로 정리
- [ ] **문서/예제 직결 링크**: 현재 패널이나 오류 상태에서 관련 가이드/샘플로 바로 이동

#### 단계 3: 지원/릴리스 운영 UX
- [ ] **support bundle 생성기**: 문서, report, 버전, 로그, 환경 정보를 한 번에 수집해 지원 요청용으로 묶기
- [ ] **릴리스 readiness 대시보드**: QA 체크, known issue, 차단 이슈, export smoke 상태를 집계한 내부용 점검 화면
- [ ] **edition/license 진입점**: 향후 제품 에디션 차이, 잠금 기능, 업그레이드 안내를 수용할 UI 훅 설계

---

## Phase 13: Polyphonic & Voice Config UX

### 목표
- 사용자가 발음 수(Voices), 보이스 할당 정책, 글로벌 모듈레이션을 시각적으로 설정하고 모니터링할 수 있는 UI를 제공한다.

### 구현 단계

- [ ] **Voice Manager Inspector**: 그래프 전체 설정에서 최대 발음 수, Stealing 모드를 선택하는 전용 패널 추가
- [ ] **Active Voice Monitor**: 현재 몇 개의 보이스가 활성화(Note-on) 상태인지 실시간으로 보여주는 미니 HUD/인디케이터
- [ ] **Voice Scoped Routing Visualizer**: 특정 연결이 '보이스별(Per-voice)'인지 '글로벌'인지 선의 스타일이나 색상으로 구분 표시

---

## Phase 14: Oversampling & High-Precision UI

### 목표
- 오버샘플링 설정과 에일리어싱 제거 상태, 신호 정밀도를 시각적으로 확인하고 제어할 수 있게 한다.

### 구현 단계

- [ ] **Oversampling Badge**: 오버샘플링이 활성화된 노드나 그룹에 `2x`, `4x` 등의 배율 배지 표시
- [ ] **Precision Mode Toggle**: 실시간 성능 위주 vs 고품질 위주 렌더링 모드를 툴바에서 원클릭 전환
- [ ] **Spectrum Aliasing Probe**: 특정 지점의 신호를 탭했을 때 에일리어싱 성분이 보이는지 간이 스펙트럼 뷰어 제공

---

## 최종 상용 UX 완성도 목표
- [ ] 노드 100개 규모 그래프에서도 편집/선택/패널 전환이 실사용 수준의 반응성을 유지
- [ ] validation/export 실패 시 사용자가 3클릭 이내에 원인 위치와 해결 경로를 찾을 수 있음
- [ ] 누락 자산, 충돌 문서, crash recovery 상황에서 데이터 손실 없이 복구 흐름 제공
- [ ] export 결과를 2분 이내에 샘플 호스트 프로젝트에 편입할 수 있는 통합 UX 제공
- [ ] 키보드 중심 사용, 고대비 테마, 고배율 환경까지 포함한 접근성 기준 충족
- [ ] 지원 요청 시 repro bundle/support bundle을 에디터 내부에서 바로 생성 가능

- [ ] 노드 그래프 전체가 1초 이내에 렌더 완료 (노드 50개 기준)
- [ ] 연결 드로잉 → 배치 전 과정에서 60fps 유지
- [ ] 신규 사용자가 10분 내에 노드를 연결하고 소리를 낼 수 있는 학습 곡선
