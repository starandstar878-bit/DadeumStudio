#include "Teul2/Runtime/AudioGraph/TRuntimeValidator.h"

#include "Teul2/Runtime/AudioGraph/TGraphCompiler.h"
#include <algorithm>
#include <cmath>

namespace Teul {
namespace {

struct RepresentativeCaseSpec {
  juce::String fixtureId;
  TRuntimeValidationRenderProfile profile;
  TRuntimeValidationStimulusSpec stimulus;
};

struct RepresentativeBenchmarkCaseSpec {
  juce::String fixtureId;
  TRuntimeValidationRenderProfile profile;
  TRuntimeValidationStimulusSpec stimulus;
  TRuntimeValidationBenchmarkThresholds thresholds;
};

TTeulDocument makeBaseDocument(const juce::String &name) {
  TTeulDocument document;
  document.meta.name = name;
  document.meta.sampleRate = 48000.0;
  document.meta.blockSize = 128;
  return document;
}

const TNodeDescriptor *requireDescriptor(const TNodeRegistry &registry,
                                         const juce::String &typeKey) {
  return registry.descriptorFor(typeKey);
}

TNode makeNodeFromDescriptor(const TNodeDescriptor &descriptor,
                             TTeulDocument &document,
                             float x,
                             float y,
                             const juce::String &label = {}) {
  TNode node;
  node.nodeId = document.allocNodeId();
  node.typeKey = descriptor.typeKey;
  node.x = x;
  node.y = y;
  node.label = label;

  for (const auto &spec : descriptor.paramSpecs)
    node.params[spec.key] = spec.defaultValue;

  for (const auto &portSpec : descriptor.portSpecs) {
    for (int ch = 0; ch < portSpec.channelCount; ++ch) {
      TPort port;
      port.portId = document.allocPortId();
      port.ownerNodeId = node.nodeId;
      port.direction = portSpec.direction;
      port.dataType = portSpec.dataType;
      if (portSpec.channelCount > 1 &&
          ch < static_cast<int>(portSpec.channelNames.size())) {
        port.name = portSpec.channelNames[static_cast<size_t>(ch)];
      } else {
        port.name = portSpec.name;
      }
      port.channelIndex = ch;
      port.maxIncomingConnections = portSpec.maxIncomingConnections;
      port.maxOutgoingConnections = portSpec.maxOutgoingConnections;
      node.ports.push_back(port);
    }
  }

  return node;
}

const TPort *findPortByName(const TNode &node, juce::StringRef portName) {
  for (const auto &port : node.ports) {
    if (port.name.equalsIgnoreCase(juce::String(portName)))
      return &port;
  }

  return nullptr;
}

bool addConnection(TTeulDocument &document,
                   NodeId fromNodeId,
                   juce::StringRef fromPortName,
                   NodeId toNodeId,
                   juce::StringRef toPortName) {
  const auto *fromNode = document.findNode(fromNodeId);
  const auto *toNode = document.findNode(toNodeId);
  if (fromNode == nullptr || toNode == nullptr)
    return false;

  const auto *fromPort = findPortByName(*fromNode, fromPortName);
  const auto *toPort = findPortByName(*toNode, toPortName);
  if (fromPort == nullptr || toPort == nullptr)
    return false;

  TConnection connection;
  connection.connectionId = document.allocConnectionId();
  connection.from = TEndpoint::makeNodePort(fromNodeId, fromPort->portId);
  connection.to = TEndpoint::makeNodePort(toNodeId, toPort->portId);
  document.connections.push_back(connection);
  return true;
}

bool appendStereoOutConnections(TTeulDocument &document,
                                NodeId sourceNodeId,
                                juce::StringRef leftPortName,
                                juce::StringRef rightPortName,
                                NodeId outputNodeId) {
  const bool leftOk = addConnection(document, sourceNodeId, leftPortName,
                                    outputNodeId, "L In");
  const bool rightOk = addConnection(document, sourceNodeId, rightPortName,
                                     outputNodeId, "R In");
  return leftOk && rightOk;
}

TTeulDocument makeRepresentativeGraphG1TonePath(const TNodeRegistry &registry) {
  TTeulDocument document = makeBaseDocument("G1 Tone Path");
  const auto *oscDesc = requireDescriptor(registry, "Teul.Source.Oscillator");
  const auto *vcaDesc = requireDescriptor(registry, "Teul.Mixer.VCA");
  const auto *outDesc = requireDescriptor(registry, "Teul.Routing.AudioOut");
  if (oscDesc == nullptr || vcaDesc == nullptr || outDesc == nullptr)
    return document;

  auto osc = makeNodeFromDescriptor(*oscDesc, document, 80.0f, 120.0f, "Tone");
  osc.params["waveform"] = 0;
  osc.params["frequency"] = 220.0f;
  osc.params["gain"] = 0.6f;

  auto vca = makeNodeFromDescriptor(*vcaDesc, document, 320.0f, 120.0f, "Amp");
  vca.params["gain"] = 0.75f;

  auto out = makeNodeFromDescriptor(*outDesc, document, 560.0f, 120.0f,
                                    "Main Out");
  out.params["volume"] = 0.9f;

  const auto oscId = osc.nodeId;
  const auto vcaId = vca.nodeId;
  const auto outId = out.nodeId;
  document.nodes.push_back(std::move(osc));
  document.nodes.push_back(std::move(vca));
  document.nodes.push_back(std::move(out));
  addConnection(document, oscId, "Out", vcaId, "In");
  addConnection(document, vcaId, "Out", outId, "L In");
  addConnection(document, vcaId, "Out", outId, "R In");
  return document;
}

TTeulDocument makeRepresentativeGraphG2FilterSweep(
    const TNodeRegistry &registry) {
  TTeulDocument document = makeBaseDocument("G2 Filter Sweep");
  const auto *oscDesc = requireDescriptor(registry, "Teul.Source.Oscillator");
  const auto *filterDesc = requireDescriptor(registry, "Teul.Filter.LowPass");
  const auto *outDesc = requireDescriptor(registry, "Teul.Routing.AudioOut");
  if (oscDesc == nullptr || filterDesc == nullptr || outDesc == nullptr)
    return document;

  auto osc = makeNodeFromDescriptor(*oscDesc, document, 80.0f, 120.0f,
                                    "Source");
  osc.params["waveform"] = 3;
  osc.params["frequency"] = 330.0f;
  osc.params["gain"] = 0.5f;

  auto filter = makeNodeFromDescriptor(*filterDesc, document, 320.0f, 120.0f,
                                       "LowPass");
  filter.params["cutoff"] = 1400.0f;
  filter.params["resonance"] = 0.9f;

  auto out = makeNodeFromDescriptor(*outDesc, document, 580.0f, 120.0f,
                                    "Main Out");
  out.params["volume"] = 0.9f;

  const auto oscId = osc.nodeId;
  const auto filterId = filter.nodeId;
  const auto outId = out.nodeId;
  document.nodes.push_back(std::move(osc));
  document.nodes.push_back(std::move(filter));
  document.nodes.push_back(std::move(out));
  addConnection(document, oscId, "Out", filterId, "In");
  addConnection(document, filterId, "Out", outId, "L In");
  addConnection(document, filterId, "Out", outId, "R In");
  return document;
}

TTeulDocument makeRepresentativeGraphG3StereoMotion(
    const TNodeRegistry &registry) {
  TTeulDocument document = makeBaseDocument("G3 Stereo Motion");
  const auto *oscDesc = requireDescriptor(registry, "Teul.Source.Oscillator");
  const auto *panDesc = requireDescriptor(registry, "Teul.Mixer.StereoPanner");
  const auto *outDesc = requireDescriptor(registry, "Teul.Routing.AudioOut");
  if (oscDesc == nullptr || panDesc == nullptr || outDesc == nullptr)
    return document;

  auto osc = makeNodeFromDescriptor(*oscDesc, document, 80.0f, 120.0f,
                                    "Source");
  osc.params["waveform"] = 1;
  osc.params["frequency"] = 220.0f;
  osc.params["gain"] = 0.55f;

  auto pan = makeNodeFromDescriptor(*panDesc, document, 320.0f, 120.0f,
                                    "Stereo Pan");
  pan.params["pan"] = -0.35f;

  auto out = makeNodeFromDescriptor(*outDesc, document, 590.0f, 120.0f,
                                    "Main Out");
  out.params["volume"] = 0.9f;

  const auto oscId = osc.nodeId;
  const auto panId = pan.nodeId;
  const auto outId = out.nodeId;
  document.nodes.push_back(std::move(osc));
  document.nodes.push_back(std::move(pan));
  document.nodes.push_back(std::move(out));
  addConnection(document, oscId, "Out", panId, "In");
  appendStereoOutConnections(document, panId, "L Out", "R Out", outId);
  return document;
}

TTeulDocument makeRepresentativeGraphG4MidiVoice(const TNodeRegistry &registry) {
  TTeulDocument document = makeBaseDocument("G4 MIDI Voice");
  const auto *midiInDesc = requireDescriptor(registry, "Teul.Source.MidiInput");
  const auto *midiToCvDesc = requireDescriptor(registry, "Teul.Midi.MidiToCV");
  const auto *adsrDesc = requireDescriptor(registry, "Teul.Mod.ADSR");
  const auto *oscDesc = requireDescriptor(registry, "Teul.Source.Oscillator");
  const auto *vcaDesc = requireDescriptor(registry, "Teul.Mixer.VCA");
  const auto *outDesc = requireDescriptor(registry, "Teul.Routing.AudioOut");
  if (midiInDesc == nullptr || midiToCvDesc == nullptr || adsrDesc == nullptr ||
      oscDesc == nullptr || vcaDesc == nullptr || outDesc == nullptr) {
    return document;
  }

  auto midiIn = makeNodeFromDescriptor(*midiInDesc, document, 60.0f, 80.0f,
                                       "MIDI In");
  auto midiToCv = makeNodeFromDescriptor(*midiToCvDesc, document, 270.0f, 80.0f,
                                         "Pitch CV");
  auto adsr = makeNodeFromDescriptor(*adsrDesc, document, 500.0f, 180.0f,
                                     "Env");
  adsr.params["attack"] = 12.0f;
  adsr.params["decay"] = 120.0f;
  adsr.params["sustain"] = 0.6f;
  adsr.params["release"] = 240.0f;

  auto osc = makeNodeFromDescriptor(*oscDesc, document, 500.0f, 40.0f,
                                    "Voice");
  osc.params["waveform"] = 2;
  osc.params["frequency"] = 16.3516f;
  osc.params["gain"] = 0.45f;

  auto vca = makeNodeFromDescriptor(*vcaDesc, document, 730.0f, 100.0f,
                                    "Amp");
  vca.params["gain"] = 0.9f;

  auto out = makeNodeFromDescriptor(*outDesc, document, 960.0f, 100.0f,
                                    "Main Out");
  out.params["volume"] = 0.9f;

  const auto midiInId = midiIn.nodeId;
  const auto midiToCvId = midiToCv.nodeId;
  const auto adsrId = adsr.nodeId;
  const auto oscId = osc.nodeId;
  const auto vcaId = vca.nodeId;
  const auto outId = out.nodeId;
  document.nodes.push_back(std::move(midiIn));
  document.nodes.push_back(std::move(midiToCv));
  document.nodes.push_back(std::move(adsr));
  document.nodes.push_back(std::move(osc));
  document.nodes.push_back(std::move(vca));
  document.nodes.push_back(std::move(out));
  addConnection(document, midiInId, "MIDI Out", midiToCvId, "MIDI In");
  addConnection(document, midiToCvId, "V/Oct", oscId, "V/Oct");
  addConnection(document, midiToCvId, "Gate", adsrId, "Gate");
  addConnection(document, oscId, "Out", vcaId, "In");
  addConnection(document, adsrId, "Env", vcaId, "CV");
  addConnection(document, vcaId, "Out", outId, "L In");
  addConnection(document, vcaId, "Out", outId, "R In");
  return document;
}

TTeulDocument makeRepresentativeGraphG5TimeTail(const TNodeRegistry &registry) {
  TTeulDocument document = makeBaseDocument("G5 Time Tail");
  const auto *oscDesc = requireDescriptor(registry, "Teul.Source.Oscillator");
  const auto *delayDesc = requireDescriptor(registry, "Teul.FX.Delay");
  const auto *outDesc = requireDescriptor(registry, "Teul.Routing.AudioOut");
  if (oscDesc == nullptr || delayDesc == nullptr || outDesc == nullptr)
    return document;

  auto osc = makeNodeFromDescriptor(*oscDesc, document, 80.0f, 120.0f,
                                    "Source");
  osc.params["waveform"] = 0;
  osc.params["frequency"] = 247.0f;
  osc.params["gain"] = 0.5f;

  auto delay = makeNodeFromDescriptor(*delayDesc, document, 330.0f, 120.0f,
                                      "Delay");
  delay.params["time"] = 180.0f;
  delay.params["feedback"] = 0.45f;
  delay.params["mix"] = 0.35f;

  auto out = makeNodeFromDescriptor(*outDesc, document, 590.0f, 120.0f,
                                    "Main Out");
  out.params["volume"] = 0.9f;

  const auto oscId = osc.nodeId;
  const auto delayId = delay.nodeId;
  const auto outId = out.nodeId;
  document.nodes.push_back(std::move(osc));
  document.nodes.push_back(std::move(delay));
  document.nodes.push_back(std::move(out));
  addConnection(document, oscId, "Out", delayId, "In");
  addConnection(document, delayId, "Out", outId, "L In");
  addConnection(document, delayId, "Out", outId, "R In");
  return document;
}

const TRuntimeValidationGraphFixture *findFixtureById(
    const std::vector<TRuntimeValidationGraphFixture> &fixtures,
    const juce::String &fixtureId) {
  for (const auto &fixture : fixtures) {
    if (fixture.fixtureId == fixtureId)
      return &fixture;
  }

  return nullptr;
}

NodeId findNodeIdByLabel(const TTeulDocument &document,
                         const juce::String &nodeLabel) {
  for (const auto &node : document.nodes) {
    if (node.label.equalsIgnoreCase(nodeLabel))
      return node.nodeId;
  }
  return kInvalidNodeId;
}

float valueForLaneAtSample(const TRuntimeValidationAutomationLane &lane,
                           int sampleIndex, int totalSamples,
                           double sampleRate) {
  if (lane.mode == TRuntimeValidationAutomationMode::Linear) {
    if (totalSamples <= 1)
      return lane.endValue;
    const float progress = juce::jlimit(
        0.0f, 1.0f,
        static_cast<float>(sampleIndex) /
            static_cast<float>(totalSamples - 1));
    return lane.startValue + ((lane.endValue - lane.startValue) * progress);
  }

  const int stepIntervalSamples = juce::jmax(
      1, juce::roundToInt(juce::jmax(0.001, lane.stepIntervalSeconds) *
                          sampleRate));
  const int segmentIndex = sampleIndex / stepIntervalSamples;
  return (segmentIndex % 2 == 0) ? lane.startValue : lane.endValue;
}

void writeError(juce::String *errorMessageOut, const juce::String &message) {
  if (errorMessageOut != nullptr)
    *errorMessageOut = message;
}

float normalizeSample(float sample) noexcept {
  if (!std::isfinite(sample))
    return sample;
  return std::abs(sample) < 1.0e-20f ? 0.0f : sample;
}

juce::String sanitizePathFragment(const juce::String &text) {
  juce::String cleaned;
  for (const auto ch : text) {
    if (juce::CharacterFunctions::isLetterOrDigit(ch))
      cleaned << ch;
    else
      cleaned << '_';
  }
  return cleaned.trimCharactersAtEnd("_").trimCharactersAtStart("_");
}

juce::String relativeArtifactPath(const juce::File &root,
                                  const juce::File &file) {
  const auto path = file.getFullPathName();
  if (path.isEmpty())
    return {};
  return file.getRelativePathFrom(root).replaceCharacter('\\', '/');
}

juce::var makeArtifactFileEntry(const juce::String &role,
                                const juce::File &root,
                                const juce::File &file) {
  auto *entry = new juce::DynamicObject();
  entry->setProperty("role", role);
  entry->setProperty("relativePath", relativeArtifactPath(root, file));
  entry->setProperty("exists", file.exists());
  return juce::var(entry);
}

bool writeTextArtifact(const juce::File &file, const juce::String &text) {
  return file.replaceWithText(text, false, false, "\r\n");
}

bool writeJsonArtifact(const juce::File &file, const juce::var &json) {
  return file.replaceWithText(juce::JSON::toString(json, true), false, false,
                              "\r\n");
}

std::vector<RepresentativeCaseSpec> makeRepresentativePrimaryCases() {
  std::vector<RepresentativeCaseSpec> cases;
  cases.push_back(
      {"G1", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeStaticRenderStimulus()});
  cases.push_back(
      {"G2", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeSweepAutomationStimulus("LowPass", "cutoff",
                                                      320.0f, 7200.0f)});
  cases.push_back(
      {"G3", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeSweepAutomationStimulus("Stereo Pan", "pan",
                                                      -1.0f, 1.0f)});
  cases.push_back(
      {"G4", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeMidiPhraseStimulus()});
  cases.push_back(
      {"G5", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeStepAutomationStimulus("Delay", "mix", 0.15f,
                                                     0.75f, 0.25)});
  return cases;
}

std::vector<RepresentativeBenchmarkCaseSpec>
makeRepresentativeBenchmarkCases() {
  std::vector<RepresentativeBenchmarkCaseSpec> cases;
  cases.push_back(
      {"G1", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeStaticRenderStimulus(), {1.00f, 0.45, 5.0}});
  cases.push_back(
      {"G2", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeSweepAutomationStimulus("LowPass", "cutoff",
                                                      320.0f, 7200.0f),
       {0.90f, 0.45, 5.0}});
  cases.push_back(
      {"G3", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeSweepAutomationStimulus("Stereo Pan", "pan",
                                                      -1.0f, 1.0f),
       {1.10f, 0.60, 5.0}});
  cases.push_back(
      {"G4", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeMidiPhraseStimulus(), {1.20f, 0.50, 5.0}});
  cases.push_back(
      {"G5", TRuntimeValidator::makePrimaryRenderProfile(),
       TRuntimeValidator::makeStepAutomationStimulus("Delay", "mix", 0.15f,
                                                     0.75f, 0.25),
       {1.00f, 0.50, 5.0}});
  return cases;
}

juce::File makeCaseArtifactDirectory(
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus) {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Builds")
      .getChildFile("TeulVerification")
      .getChildFile("EditableRoundTrip")
      .getChildFile(sanitizePathFragment(fixture.fixtureId) + "_" +
                    sanitizePathFragment(stimulus.stimulusId) + "_" +
                    sanitizePathFragment(profile.profileId));
}

juce::String exportReportToText(const TExportReport &report) {
  juce::String text;
  text << "Export Report\r\n";
  text << "-------------\r\n";
  text << "Mode: " << (report.mode == TExportMode::EditableGraph ? "EditableGraph" : "RuntimeModule") << "\r\n";
  text << "Dry Run: " << (report.dryRunOnly ? "Yes" : "No") << "\r\n\r\n";
  
  text << "Summary:\r\n";
  text << "  Nodes: " << report.summary.nodeCount << "\r\n";
  text << "  Connections: " << report.summary.connectionCount << "\r\n";
  text << "  Exposed Params: " << report.summary.exposedParamCount << "\r\n\r\n";

  if (!report.issues.empty()) {
    text << "Issues:\r\n";
    for (const auto &issue : report.issues) {
      juce::String severity;
      switch (issue.severity) {
        case TExportIssueSeverity::Info:    severity = "[INFO]"; break;
        case TExportIssueSeverity::Warning: severity = "[WARN]"; break;
        case TExportIssueSeverity::Error:   severity = "[ERR ]"; break;
      }
      text << "  " << severity << " " << issue.message << "\r\n";
    }
  } else {
    text << "No issues found.\r\n";
  }
  return text;
}

void finalizeCaseArtifacts(const juce::File &artifactDirectory,
                           const TRuntimeValidationParityReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());

  juce::String summary;
  summary << "graphId=" << report.graphId << "\r\n";
  summary << "stimulusId=" << report.stimulusId << "\r\n";
  summary << "profileId=" << report.profileId << "\r\n";
  summary << "modeId=" << report.modeId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "importedDocumentLoaded="
          << (report.importedDocumentLoaded ? "true" : "false") << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalSamples=" << report.totalSamples << "\r\n";
  summary << "comparedChannels=" << report.comparedChannels << "\r\n";
  summary << "maxAbsoluteError=" << juce::String(report.maxAbsoluteError, 9)
          << "\r\n";
  summary << "rmsError=" << juce::String(report.rmsError, 12) << "\r\n";
  summary << "firstMismatchChannel=" << report.firstMismatchChannel
          << "\r\n";
  summary << "firstMismatchSample=" << report.firstMismatchSample
          << "\r\n";
  summary << "exportWarnings=" << report.exportWarningCount << "\r\n";
  summary << "exportErrors=" << report.exportErrorCount << "\r\n";
  if (report.failureReason.isNotEmpty())
    summary << "failureReason=" << report.failureReason << "\r\n";
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("parity-summary.txt"), summary));

  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("export-report.txt"),
      exportReportToText(report.exportReport)));

  if (report.failureReason.isNotEmpty()) {
    juce::ignoreUnused(writeTextArtifact(
        artifactDirectory.getChildFile("parity-failure.txt"),
        report.failureReason));
  }

  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry(
      "paritySummary", artifactDirectory,
      artifactDirectory.getChildFile("parity-summary.txt")));
  files.add(makeArtifactFileEntry(
      "exportReport", artifactDirectory,
      artifactDirectory.getChildFile("export-report.txt")));
  files.add(makeArtifactFileEntry(
      "bundle", artifactDirectory,
      artifactDirectory.getChildFile("artifact-bundle.json")));

  auto *bundle = new juce::DynamicObject();
  bundle->setProperty("kind", "teul-verification-artifact-bundle");
  bundle->setProperty("scope", "case");
  bundle->setProperty("graphId", report.graphId);
  bundle->setProperty("stimulusId", report.stimulusId);
  bundle->setProperty("profileId", report.profileId);
  bundle->setProperty("modeId", report.modeId);
  bundle->setProperty("passed", report.passed);
  bundle->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  bundle->setProperty("files", juce::var(files));
  if (report.failureReason.isNotEmpty())
    bundle->setProperty("failureReason", report.failureReason);
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      juce::var(bundle)));
}

void finalizeSuiteArtifacts(const juce::File &artifactDirectory,
                            const TRuntimeValidationParitySuiteReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());

  juce::String summary;
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "suiteId=" << report.suiteId << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalCaseCount=" << report.totalCaseCount << "\r\n";
  summary << "passedCaseCount=" << report.passedCaseCount << "\r\n";
  summary << "failedCaseCount=" << report.failedCaseCount << "\r\n";
  for (const auto &caseReport : report.caseReports) {
    summary << "\r\ncase=" << caseReport.graphId << "/"
            << caseReport.stimulusId << "/" << caseReport.profileId
            << "\r\n";
    summary << "passed=" << (caseReport.passed ? "true" : "false")
            << "\r\n";
    if (caseReport.failureReason.isNotEmpty())
      summary << "failureReason=" << caseReport.failureReason << "\r\n";
  }
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("matrix-summary.txt"), summary));

  juce::Array<juce::var> cases;
  for (const auto &caseReport : report.caseReports) {
    auto *entry = new juce::DynamicObject();
    entry->setProperty("graphId", caseReport.graphId);
    entry->setProperty("stimulusId", caseReport.stimulusId);
    entry->setProperty("profileId", caseReport.profileId);
    entry->setProperty("modeId", caseReport.modeId);
    entry->setProperty("passed", caseReport.passed);
    entry->setProperty("artifactDirectory", caseReport.artifactDirectory);
    if (caseReport.failureReason.isNotEmpty())
      entry->setProperty("failureReason", caseReport.failureReason);
    cases.add(juce::var(entry));
  }

  auto *bundle = new juce::DynamicObject();
  bundle->setProperty("kind", "teul-verification-artifact-bundle");
  bundle->setProperty("scope", "suite");
  bundle->setProperty("suiteId", report.suiteId);
  bundle->setProperty("passed", report.passed);
  bundle->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  bundle->setProperty("totalCaseCount", report.totalCaseCount);
  bundle->setProperty("passedCaseCount", report.passedCaseCount);
  bundle->setProperty("failedCaseCount", report.failedCaseCount);
  bundle->setProperty("cases", juce::var(cases));
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      juce::var(bundle)));
}
juce::File baselineSuiteDirectory() {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Source")
      .getChildFile("Teul")
      .getChildFile("Verification")
      .getChildFile("GoldenAudio")
      .getChildFile("RepresentativePrimary");
}

juce::File verifySuiteArtifactDirectory() {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Builds")
      .getChildFile("TeulVerification")
      .getChildFile("GoldenAudio")
      .getChildFile("RepresentativePrimary_verify");
}

juce::File makeGoldenCaseDirectory(
    const juce::File &root,
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus) {
  return root.getChildFile(sanitizePathFragment(fixture.fixtureId) + "_" +
                           sanitizePathFragment(stimulus.stimulusId) + "_" +
                           sanitizePathFragment(profile.profileId));
}

bool writeWaveFile(const juce::File &file,
                   const juce::AudioBuffer<float> &buffer,
                   double sampleRate,
                   juce::String *errorMessageOut) {
  if (sampleRate <= 0.0 || buffer.getNumChannels() <= 0 ||
      buffer.getNumSamples() <= 0) {
    writeError(errorMessageOut, "Invalid golden audio buffer.");
    return false;
  }

  juce::ignoreUnused(file.getParentDirectory().createDirectory());
  auto output = file.createOutputStream();
  if (output == nullptr) {
    writeError(errorMessageOut,
               "Failed to create golden audio output stream.");
    return false;
  }

  juce::WavAudioFormat wavFormat;
  auto *rawStream = output.release();
  std::unique_ptr<juce::AudioFormatWriter> writer(
      wavFormat.createWriterFor(rawStream, sampleRate,
                                static_cast<unsigned int>(buffer.getNumChannels()),
                                32, {}, 0));
  if (writer == nullptr) {
    delete rawStream;
    writeError(errorMessageOut, "Failed to create golden audio WAV writer.");
    return false;
  }

  if (!writer->writeFromAudioSampleBuffer(buffer, 0, buffer.getNumSamples())) {
    writeError(errorMessageOut, "Failed to write golden audio WAV data.");
    return false;
  }

  return true;
}

bool readWaveFile(const juce::File &file,
                  juce::AudioBuffer<float> &bufferOut,
                  double &sampleRateOut,
                  juce::String *errorMessageOut) {
  juce::AudioFormatManager formatManager;
  formatManager.registerBasicFormats();
  std::unique_ptr<juce::AudioFormatReader> reader(
      formatManager.createReaderFor(file));
  if (reader == nullptr) {
    writeError(errorMessageOut, "Failed to open golden audio WAV file.");
    return false;
  }

  sampleRateOut = reader->sampleRate;
  const int channels = static_cast<int>(reader->numChannels);
  const int samples = static_cast<int>(reader->lengthInSamples);
  if (channels <= 0 || samples <= 0) {
    writeError(errorMessageOut, "Golden audio WAV file is empty.");
    return false;
  }

  bufferOut.setSize(channels, samples, false, false, true);
  if (!reader->read(&bufferOut, 0, samples, 0, true, true)) {
    writeError(errorMessageOut, "Failed to read golden audio WAV data.");
    return false;
  }

  return true;
}

juce::var makeGoldenMetadata(
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus,
    const TRuntimeValidationRenderResult &renderResult,
    const juce::File &caseDirectory) {
  auto *root = new juce::DynamicObject();
  root->setProperty("graphId", fixture.fixtureId);
  root->setProperty("displayName", fixture.displayName);
  root->setProperty("stimulusId", stimulus.stimulusId);
  root->setProperty("profileId", profile.profileId);
  root->setProperty("sampleRate", profile.sampleRate);
  root->setProperty("blockSize", profile.blockSize);
  root->setProperty("outputChannels", profile.outputChannels);
  root->setProperty("durationSeconds", profile.durationSeconds);
  root->setProperty("totalSamples", renderResult.totalSamples);
  root->setProperty("renderedBlockCount", renderResult.renderedBlockCount);
  root->setProperty(
      "baselineWave",
      relativeArtifactPath(caseDirectory,
                           caseDirectory.getChildFile("golden-output.wav")));
  root->setProperty(
      "recordedAtUtcMilliseconds",
      juce::Time::getCurrentTime().toMilliseconds());
  return juce::var(root);
}

juce::String buildGoldenRecordSummaryText(
    const TRuntimeValidationGoldenAudioReport &report,
    const TRuntimeValidationRenderProfile &profile) {
  juce::String summary;
  summary << "graphId=" << report.graphId << "\r\n";
  summary << "stimulusId=" << report.stimulusId << "\r\n";
  summary << "profileId=" << report.profileId << "\r\n";
  summary << "modeId=" << report.modeId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "baselineDirectory=" << report.baselineDirectory << "\r\n";
  summary << "totalSamples=" << report.totalSamples << "\r\n";
  summary << "sampleRate=" << juce::String(profile.sampleRate, 1) << "\r\n";
  summary << "blockSize=" << profile.blockSize << "\r\n";
  if (report.failureReason.isNotEmpty())
    summary << "failureReason=" << report.failureReason << "\r\n";
  return summary;
}

juce::String buildGoldenVerifySummaryText(
    const TRuntimeValidationGoldenAudioReport &report) {
  juce::String summary;
  summary << "graphId=" << report.graphId << "\r\n";
  summary << "stimulusId=" << report.stimulusId << "\r\n";
  summary << "profileId=" << report.profileId << "\r\n";
  summary << "modeId=" << report.modeId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "baselineExists=" << (report.baselineExists ? "true" : "false")
          << "\r\n";
  summary << "baselineDirectory=" << report.baselineDirectory << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalSamples=" << report.totalSamples << "\r\n";
  summary << "comparedChannels=" << report.comparedChannels << "\r\n";
  summary << "maxAbsoluteError=" << juce::String(report.maxAbsoluteError, 9)
          << "\r\n";
  summary << "rmsError=" << juce::String(report.rmsError, 12) << "\r\n";
  summary << "firstMismatchChannel=" << report.firstMismatchChannel << "\r\n";
  summary << "firstMismatchSample=" << report.firstMismatchSample << "\r\n";
  if (report.failureReason.isNotEmpty())
    summary << "failureReason=" << report.failureReason << "\r\n";
  return summary;
}

juce::var makeGoldenCaseArtifactBundle(
    const juce::File &rootDirectory,
    const TRuntimeValidationGoldenAudioReport &report,
    bool verifyMode) {
  juce::Array<juce::var> files;
  const auto addFile = [&](const juce::String &role, const juce::File &file) {
    if (file.getFullPathName().isNotEmpty())
      files.add(makeArtifactFileEntry(role, rootDirectory, file));
  };

  if (verifyMode) {
    addFile("goldenSummary", rootDirectory.getChildFile("golden-summary.txt"));
    addFile("failureSummary", rootDirectory.getChildFile("golden-failure.txt"));
  } else {
    addFile("goldenSummary", rootDirectory.getChildFile("golden-summary.txt"));
    addFile("goldenMetadata",
            rootDirectory.getChildFile("golden-metadata.json"));
    addFile("goldenOutput", rootDirectory.getChildFile("golden-output.wav"));
  }

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope",
                    verifyMode ? "golden-verify-case"
                               : "golden-record-case");
  root->setProperty("graphId", report.graphId);
  root->setProperty("stimulusId", report.stimulusId);
  root->setProperty("profileId", report.profileId);
  root->setProperty("modeId", report.modeId);
  root->setProperty("passed", report.passed);
  root->setProperty("baselineDirectory", report.baselineDirectory);
  if (report.artifactDirectory.isNotEmpty())
    root->setProperty("artifactDirectory", report.artifactDirectory);
  root->setProperty("totalSamples", report.totalSamples);
  root->setProperty("comparedChannels", report.comparedChannels);
  root->setProperty("maxAbsoluteError", report.maxAbsoluteError);
  root->setProperty("rmsError", report.rmsError);
  root->setProperty("firstMismatchChannel", report.firstMismatchChannel);
  root->setProperty("firstMismatchSample", report.firstMismatchSample);
  root->setProperty("baselineExists", report.baselineExists);
  if (report.failureReason.isNotEmpty())
    root->setProperty("failureReason", report.failureReason);
  root->setProperty("files", juce::var(files));
  return juce::var(root);
}

juce::String buildGoldenSuiteSummaryText(
    const TRuntimeValidationGoldenAudioSuiteReport &report) {
  juce::String summary;
  summary << "suiteId=" << report.suiteId << "\r\n";
  summary << "modeId=" << report.modeId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "baselineDirectory=" << report.baselineDirectory << "\r\n";
  if (report.artifactDirectory.isNotEmpty())
    summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalCaseCount=" << report.totalCaseCount << "\r\n";
  summary << "passedCaseCount=" << report.passedCaseCount << "\r\n";
  summary << "failedCaseCount=" << report.failedCaseCount << "\r\n\r\n";
  for (const auto &caseReport : report.caseReports) {
    summary << "case=" << caseReport.graphId << "/" << caseReport.stimulusId
            << "/" << caseReport.profileId << "\r\n";
    summary << "passed=" << (caseReport.passed ? "true" : "false")
            << "\r\n";
    summary << "baselineDirectory=" << caseReport.baselineDirectory
            << "\r\n";
    if (caseReport.artifactDirectory.isNotEmpty())
      summary << "artifactDirectory=" << caseReport.artifactDirectory
              << "\r\n";
    if (caseReport.failureReason.isNotEmpty())
      summary << "failureReason=" << caseReport.failureReason << "\r\n";
    summary << "\r\n";
  }
  return summary;
}

juce::var makeGoldenSuiteArtifactBundle(
    const juce::File &rootDirectory,
    const TRuntimeValidationGoldenAudioSuiteReport &report,
    bool verifyMode) {
  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry(
      verifyMode ? "goldenVerifySummary" : "goldenRecordSummary",
      rootDirectory, rootDirectory.getChildFile("golden-suite-summary.txt")));

  juce::Array<juce::var> cases;
  for (const auto &caseReport : report.caseReports) {
    auto *entry = new juce::DynamicObject();
    entry->setProperty("graphId", caseReport.graphId);
    entry->setProperty("stimulusId", caseReport.stimulusId);
    entry->setProperty("profileId", caseReport.profileId);
    entry->setProperty("modeId", caseReport.modeId);
    entry->setProperty("passed", caseReport.passed);
    entry->setProperty("baselineDirectory", caseReport.baselineDirectory);
    if (caseReport.artifactDirectory.isNotEmpty())
      entry->setProperty("artifactDirectory", caseReport.artifactDirectory);
    if (caseReport.failureReason.isNotEmpty())
      entry->setProperty("failureReason", caseReport.failureReason);
    cases.add(juce::var(entry));
  }

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope",
                    verifyMode ? "golden-verify-suite"
                               : "golden-record-suite");
  root->setProperty("suiteId", report.suiteId);
  root->setProperty("modeId", report.modeId);
  root->setProperty("passed", report.passed);
  root->setProperty("baselineDirectory", report.baselineDirectory);
  if (report.artifactDirectory.isNotEmpty())
    root->setProperty("artifactDirectory", report.artifactDirectory);
  root->setProperty("totalCaseCount", report.totalCaseCount);
  root->setProperty("passedCaseCount", report.passedCaseCount);
  root->setProperty("failedCaseCount", report.failedCaseCount);
  root->setProperty("files", juce::var(files));
  root->setProperty("cases", juce::var(cases));
  return juce::var(root);
}

void finalizeGoldenRecordCaseArtifacts(
    const juce::File &caseDirectory,
    const TRuntimeValidationGoldenAudioReport &report,
    const TRuntimeValidationRenderProfile &profile) {
  juce::ignoreUnused(writeTextArtifact(
      caseDirectory.getChildFile("golden-summary.txt"),
      buildGoldenRecordSummaryText(report, profile)));
  juce::ignoreUnused(writeJsonArtifact(
      caseDirectory.getChildFile("artifact-bundle.json"),
      makeGoldenCaseArtifactBundle(caseDirectory, report, false)));
}

void finalizeGoldenVerifyCaseArtifacts(
    const juce::File &artifactDirectory,
    const TRuntimeValidationGoldenAudioReport &report) {
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("golden-summary.txt"),
      buildGoldenVerifySummaryText(report)));
  if (report.failureReason.isNotEmpty()) {
    juce::ignoreUnused(writeTextArtifact(
        artifactDirectory.getChildFile("golden-failure.txt"),
        report.failureReason));
  }
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      makeGoldenCaseArtifactBundle(artifactDirectory, report, true)));
}

void finalizeGoldenSuiteArtifacts(
    const juce::File &directory,
    const TRuntimeValidationGoldenAudioSuiteReport &report,
    bool verifyMode) {
  juce::ignoreUnused(directory.createDirectory());
  juce::ignoreUnused(writeTextArtifact(
      directory.getChildFile("golden-suite-summary.txt"),
      buildGoldenSuiteSummaryText(report)));
  juce::ignoreUnused(writeJsonArtifact(
      directory.getChildFile("artifact-bundle.json"),
      makeGoldenSuiteArtifactBundle(directory, report, verifyMode)));
}

bool compareWithGolden(const TRuntimeValidationRenderResult &renderResult,
                       const juce::AudioBuffer<float> &goldenBuffer,
                       TRuntimeValidationGoldenAudioReport &reportOut,
                       float maxAbsoluteTolerance,
                       double rmsTolerance) {
  const int channels = juce::jmin(renderResult.audioBuffer.getNumChannels(),
                                  goldenBuffer.getNumChannels());
  const int samples = juce::jmin(renderResult.audioBuffer.getNumSamples(),
                                 goldenBuffer.getNumSamples());
  reportOut.totalSamples = samples;
  reportOut.comparedChannels = channels;
  if (channels <= 0 || samples <= 0) {
    reportOut.failureReason =
        "Golden audio compare produced an empty audio buffer.";
    return false;
  }

  double squaredErrorSum = 0.0;
  int comparedSampleCount = 0;
  for (int channel = 0; channel < channels; ++channel) {
    const float *lhs = renderResult.audioBuffer.getReadPointer(channel);
    const float *rhs = goldenBuffer.getReadPointer(channel);
    for (int sampleIndex = 0; sampleIndex < samples; ++sampleIndex) {
      const float a = normalizeSample(lhs[sampleIndex]);
      const float b = normalizeSample(rhs[sampleIndex]);
      if (!std::isfinite(a) || !std::isfinite(b)) {
        reportOut.firstMismatchChannel = channel;
        reportOut.firstMismatchSample = sampleIndex;
        reportOut.failureReason =
            "Golden audio compare encountered NaN or Inf.";
        return false;
      }

      const double error = static_cast<double>(a) - static_cast<double>(b);
      const float absError = static_cast<float>(std::abs(error));
      reportOut.maxAbsoluteError =
          juce::jmax(reportOut.maxAbsoluteError, absError);
      squaredErrorSum += error * error;
      ++comparedSampleCount;
      if (reportOut.firstMismatchSample < 0 &&
          absError > maxAbsoluteTolerance) {
        reportOut.firstMismatchChannel = channel;
        reportOut.firstMismatchSample = sampleIndex;
      }
    }
  }

  reportOut.rmsError =
      comparedSampleCount > 0
          ? std::sqrt(squaredErrorSum /
                      static_cast<double>(comparedSampleCount))
          : 0.0;
  reportOut.passed = reportOut.maxAbsoluteError <= maxAbsoluteTolerance &&
                     reportOut.rmsError <= rmsTolerance;
  if (!reportOut.passed && reportOut.failureReason.isEmpty()) {
    reportOut.failureReason =
        "Golden audio output drift exceeded tolerance.";
  }
  return reportOut.passed;
}
bool isFiniteRuntimeStats(const TTeulRuntime::RuntimeStats &stats) {
  return std::isfinite(stats.sampleRate) && std::isfinite(stats.cpuLoadPercent) &&
         std::isfinite(stats.lastBuildMilliseconds) &&
         std::isfinite(stats.maxBuildMilliseconds) &&
         std::isfinite(stats.lastProcessMilliseconds) &&
         std::isfinite(stats.maxProcessMilliseconds);
}

TTeulRuntime::RuntimeStats
maxRuntimeStats(const TTeulRuntime::RuntimeStats &lhs,
                const TTeulRuntime::RuntimeStats &rhs) {
  TTeulRuntime::RuntimeStats result = lhs;
  result.sampleRate = rhs.sampleRate;
  result.preparedBlockSize = juce::jmax(lhs.preparedBlockSize, rhs.preparedBlockSize);
  result.lastInputChannels = juce::jmax(lhs.lastInputChannels, rhs.lastInputChannels);
  result.lastOutputChannels = juce::jmax(lhs.lastOutputChannels, rhs.lastOutputChannels);
  result.activeNodeCount = juce::jmax(lhs.activeNodeCount, rhs.activeNodeCount);
  result.allocatedPortChannels =
      juce::jmax(lhs.allocatedPortChannels, rhs.allocatedPortChannels);
  result.largestBlockSeen = juce::jmax(lhs.largestBlockSeen, rhs.largestBlockSeen);
  result.largestOutputChannelCountSeen = juce::jmax(
      lhs.largestOutputChannelCountSeen, rhs.largestOutputChannelCountSeen);
  result.smoothingActiveCount =
      juce::jmax(lhs.smoothingActiveCount, rhs.smoothingActiveCount);
  result.processBlockCount = juce::jmax(lhs.processBlockCount, rhs.processBlockCount);
  result.rebuildRequestCount =
      juce::jmax(lhs.rebuildRequestCount, rhs.rebuildRequestCount);
  result.rebuildCommitCount =
      juce::jmax(lhs.rebuildCommitCount, rhs.rebuildCommitCount);
  result.paramChangeCount = juce::jmax(lhs.paramChangeCount, rhs.paramChangeCount);
  result.droppedParamChangeCount =
      juce::jmax(lhs.droppedParamChangeCount, rhs.droppedParamChangeCount);
  result.droppedParamNotificationCount = juce::jmax(
      lhs.droppedParamNotificationCount, rhs.droppedParamNotificationCount);
  result.activeGeneration = juce::jmax(lhs.activeGeneration, rhs.activeGeneration);
  result.pendingGeneration = juce::jmax(lhs.pendingGeneration, rhs.pendingGeneration);
  result.rebuildPending = lhs.rebuildPending || rhs.rebuildPending;
  result.clipDetected = lhs.clipDetected || rhs.clipDetected;
  result.denormalDetected = lhs.denormalDetected || rhs.denormalDetected;
  result.xrunDetected = lhs.xrunDetected || rhs.xrunDetected;
  result.mutedFallbackActive = lhs.mutedFallbackActive || rhs.mutedFallbackActive;
  result.cpuLoadPercent = juce::jmax(lhs.cpuLoadPercent, rhs.cpuLoadPercent);
  result.lastBuildMilliseconds =
      juce::jmax(lhs.lastBuildMilliseconds, rhs.lastBuildMilliseconds);
  result.maxBuildMilliseconds =
      juce::jmax(lhs.maxBuildMilliseconds, rhs.maxBuildMilliseconds);
  result.lastProcessMilliseconds =
      juce::jmax(lhs.lastProcessMilliseconds, rhs.lastProcessMilliseconds);
  result.maxProcessMilliseconds =
      juce::jmax(lhs.maxProcessMilliseconds, rhs.maxProcessMilliseconds);
  return result;
}

juce::File makeStressSuiteArtifactDirectory(const juce::String &suiteId) {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Builds")
      .getChildFile("TeulVerification")
      .getChildFile("StressSoak")
      .getChildFile(sanitizePathFragment(suiteId));
}

juce::File makeStressCaseArtifactDirectory(
    const juce::File &suiteDirectory,
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus) {
  return suiteDirectory.getChildFile(sanitizePathFragment(fixture.fixtureId) + "_" +
                                     sanitizePathFragment(stimulus.stimulusId) + "_" +
                                     sanitizePathFragment(profile.profileId));
}

juce::String buildStressCaseSummaryText(
    const TRuntimeValidationStressCaseReport &report) {
  juce::String summary;
  summary << "graphId=" << report.graphId << "\r\n";
  summary << "stimulusId=" << report.stimulusId << "\r\n";
  summary << "profileId=" << report.profileId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "iterationCount=" << report.iterationCount << "\r\n";
  summary << "totalRenderedSamples=" << report.totalRenderedSamples << "\r\n";
  summary << "totalRenderedBlocks=" << report.totalRenderedBlocks << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "worstCpuLoadPercent="
          << juce::String(report.worstRuntimeStats.cpuLoadPercent, 6) << "\r\n";
  summary << "worstMaxProcessMilliseconds="
          << juce::String(report.worstRuntimeStats.maxProcessMilliseconds, 6)
          << "\r\n";
  summary << "xrunDetected="
          << (report.worstRuntimeStats.xrunDetected ? "true" : "false")
          << "\r\n";
  summary << "clipDetected="
          << (report.worstRuntimeStats.clipDetected ? "true" : "false")
          << "\r\n";
  summary << "denormalDetected="
          << (report.worstRuntimeStats.denormalDetected ? "true" : "false")
          << "\r\n";
  summary << "mutedFallbackActive="
          << (report.worstRuntimeStats.mutedFallbackActive ? "true" : "false")
          << "\r\n";
  if (report.failureReason.isNotEmpty())
    summary << "failureReason=" << report.failureReason << "\r\n";
  return summary;
}

juce::var makeStressCaseArtifactBundle(
    const juce::File &artifactDirectory,
    const TRuntimeValidationStressCaseReport &report) {
  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry("stressCaseSummary", artifactDirectory,
                                  artifactDirectory.getChildFile("case-summary.txt")));

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope", "stress-case");
  root->setProperty("graphId", report.graphId);
  root->setProperty("stimulusId", report.stimulusId);
  root->setProperty("profileId", report.profileId);
  root->setProperty("passed", report.passed);
  root->setProperty("iterationCount", report.iterationCount);
  root->setProperty("totalRenderedSamples", report.totalRenderedSamples);
  root->setProperty("totalRenderedBlocks", report.totalRenderedBlocks);
  root->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  root->setProperty("worstCpuLoadPercent", report.worstRuntimeStats.cpuLoadPercent);
  root->setProperty("worstMaxProcessMilliseconds",
                    report.worstRuntimeStats.maxProcessMilliseconds);
  root->setProperty("xrunDetected", report.worstRuntimeStats.xrunDetected);
  root->setProperty("clipDetected", report.worstRuntimeStats.clipDetected);
  root->setProperty("denormalDetected", report.worstRuntimeStats.denormalDetected);
  root->setProperty("mutedFallbackActive",
                    report.worstRuntimeStats.mutedFallbackActive);
  if (report.failureReason.isNotEmpty())
    root->setProperty("failureReason", report.failureReason);
  root->setProperty("files", juce::var(files));
  return juce::var(root);
}

void finalizeStressCaseArtifacts(
    const juce::File &artifactDirectory,
    const TRuntimeValidationStressCaseReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("case-summary.txt"),
      buildStressCaseSummaryText(report)));
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      makeStressCaseArtifactBundle(artifactDirectory, report)));
}

juce::String buildStressSuiteSummaryText(
    const TRuntimeValidationStressSuiteReport &report) {
  juce::String summary;
  summary << "suiteId=" << report.suiteId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "iterationCount=" << report.iterationCount << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalCaseCount=" << report.totalCaseCount << "\r\n";
  summary << "passedCaseCount=" << report.passedCaseCount << "\r\n";
  summary << "failedCaseCount=" << report.failedCaseCount << "\r\n\r\n";
  for (const auto &caseReport : report.caseReports) {
    summary << "case=" << caseReport.graphId << "/" << caseReport.stimulusId
            << "/" << caseReport.profileId << "\r\n";
    summary << "passed=" << (caseReport.passed ? "true" : "false")
            << "\r\n";
    summary << "artifactDirectory=" << caseReport.artifactDirectory << "\r\n";
    summary << "iterationCount=" << caseReport.iterationCount << "\r\n";
    summary << "totalRenderedSamples=" << caseReport.totalRenderedSamples
            << "\r\n";
    summary << "totalRenderedBlocks=" << caseReport.totalRenderedBlocks
            << "\r\n";
    summary << "worstCpuLoadPercent="
            << juce::String(caseReport.worstRuntimeStats.cpuLoadPercent, 6)
            << "\r\n";
    summary << "worstMaxProcessMilliseconds="
            << juce::String(caseReport.worstRuntimeStats.maxProcessMilliseconds, 6)
            << "\r\n";
    if (caseReport.failureReason.isNotEmpty())
      summary << "failureReason=" << caseReport.failureReason << "\r\n";
    summary << "\r\n";
  }
  return summary;
}

juce::var makeStressSuiteArtifactBundle(
    const juce::File &artifactDirectory,
    const TRuntimeValidationStressSuiteReport &report) {
  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry("stressSummary", artifactDirectory,
                                  artifactDirectory.getChildFile("stress-summary.txt")));

  juce::Array<juce::var> cases;
  for (const auto &caseReport : report.caseReports) {
    auto *entry = new juce::DynamicObject();
    entry->setProperty("graphId", caseReport.graphId);
    entry->setProperty("stimulusId", caseReport.stimulusId);
    entry->setProperty("profileId", caseReport.profileId);
    entry->setProperty("passed", caseReport.passed);
    entry->setProperty("iterationCount", caseReport.iterationCount);
    entry->setProperty("artifactDirectory", caseReport.artifactDirectory);
    if (caseReport.artifactDirectory.isNotEmpty()) {
      const auto caseDir = juce::File(caseReport.artifactDirectory);
      entry->setProperty("relativeArtifactDirectory",
                         relativeArtifactPath(artifactDirectory, caseDir));
      entry->setProperty(
          "bundleRelativePath",
          relativeArtifactPath(
              artifactDirectory,
              caseDir.getChildFile("artifact-bundle.json")));
    }
    if (caseReport.failureReason.isNotEmpty())
      entry->setProperty("failureReason", caseReport.failureReason);
    cases.add(juce::var(entry));
  }

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope", "stress-suite");
  root->setProperty("suiteId", report.suiteId);
  root->setProperty("passed", report.passed);
  root->setProperty("iterationCount", report.iterationCount);
  root->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  root->setProperty("totalCaseCount", report.totalCaseCount);
  root->setProperty("passedCaseCount", report.passedCaseCount);
  root->setProperty("failedCaseCount", report.failedCaseCount);
  root->setProperty("files", juce::var(files));
  root->setProperty("cases", juce::var(cases));
  return juce::var(root);
}

void finalizeStressSuiteArtifacts(
    const juce::File &artifactDirectory,
    const TRuntimeValidationStressSuiteReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("stress-summary.txt"),
      buildStressSuiteSummaryText(report)));
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      makeStressSuiteArtifactBundle(artifactDirectory, report)));
}

juce::File makeBenchmarkSuiteArtifactDirectory(const juce::String &suiteId) {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Builds")
      .getChildFile("TeulVerification")
      .getChildFile("Benchmark")
      .getChildFile(sanitizePathFragment(suiteId));
}

juce::File makeBenchmarkCaseArtifactDirectory(
    const juce::File &suiteDirectory,
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus) {
  return suiteDirectory.getChildFile(sanitizePathFragment(fixture.fixtureId) + "_" +
                                     sanitizePathFragment(stimulus.stimulusId) + "_" +
                                     sanitizePathFragment(profile.profileId));
}

juce::File makeBenchmarkSuiteHistoryFile(const juce::String &suiteId) {
  return juce::File::getCurrentWorkingDirectory()
      .getChildFile("Builds")
      .getChildFile("TeulVerification")
      .getChildFile("Benchmark")
      .getChildFile(sanitizePathFragment(suiteId) + "-history.json");
}
juce::var buildBenchmarkHistoryEntry(
    const TRuntimeValidationBenchmarkSuiteReport &report) {
  double peakCpuLoadPercent = 0.0;
  double peakProcessMilliseconds = 0.0;
  double peakBuildMilliseconds = 0.0;
  juce::Array<juce::var> cases;
  for (const auto &caseReport : report.caseReports) {
    peakCpuLoadPercent = juce::jmax(
        peakCpuLoadPercent,
        static_cast<double>(caseReport.worstRuntimeStats.cpuLoadPercent));
    peakProcessMilliseconds = juce::jmax(
        peakProcessMilliseconds,
        caseReport.worstRuntimeStats.maxProcessMilliseconds);
    peakBuildMilliseconds = juce::jmax(
        peakBuildMilliseconds,
        caseReport.worstRuntimeStats.maxBuildMilliseconds);

    auto *caseObject = new juce::DynamicObject();
    caseObject->setProperty("graphId", caseReport.graphId);
    caseObject->setProperty("stimulusId", caseReport.stimulusId);
    caseObject->setProperty("profileId", caseReport.profileId);
    caseObject->setProperty("passed", caseReport.passed);
    caseObject->setProperty("worstCpuLoadPercent",
                            caseReport.worstRuntimeStats.cpuLoadPercent);
    caseObject->setProperty("worstMaxProcessMilliseconds",
                            caseReport.worstRuntimeStats.maxProcessMilliseconds);
    caseObject->setProperty("worstMaxBuildMilliseconds",
                            caseReport.worstRuntimeStats.maxBuildMilliseconds);
    if (caseReport.failureReason.isNotEmpty())
      caseObject->setProperty("failureReason", caseReport.failureReason);
    cases.add(juce::var(caseObject));
  }

  auto *entry = new juce::DynamicObject();
  entry->setProperty("timestampUtc",
                     juce::Time::getCurrentTime().toISO8601(true));
  entry->setProperty("suiteId", report.suiteId);
  entry->setProperty("passed", report.passed);
  entry->setProperty("failedCaseCount", report.failedCaseCount);
  entry->setProperty("iterationCount", report.iterationCount);
  entry->setProperty("peakCpuLoadPercent", peakCpuLoadPercent);
  entry->setProperty("peakMaxProcessMilliseconds", peakProcessMilliseconds);
  entry->setProperty("peakMaxBuildMilliseconds", peakBuildMilliseconds);
  entry->setProperty("cases", juce::var(cases));
  return juce::var(entry);
}

void appendBenchmarkHistory(
    const TRuntimeValidationBenchmarkSuiteReport &report) {
  const auto historyFile = makeBenchmarkSuiteHistoryFile(report.suiteId);
  juce::ignoreUnused(historyFile.getParentDirectory().createDirectory());

  juce::Array<juce::var> entries;
  if (historyFile.existsAsFile()) {
    juce::var parsed;
    const auto parseResult =
        juce::JSON::parse(historyFile.loadFileAsString(), parsed);
    if (parseResult.wasOk() && parsed.isObject()) {
      if (const auto *object = parsed.getDynamicObject()) {
        const auto existingEntries = object->getProperty("entries");
        if (existingEntries.isArray())
          entries = *existingEntries.getArray();
      }
    }
  }

  entries.add(buildBenchmarkHistoryEntry(report));
  while (entries.size() > 24)
    entries.remove(0);

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-benchmark-history");
  root->setProperty("suiteId", report.suiteId);
  root->setProperty("entries", juce::var(entries));
  juce::ignoreUnused(writeJsonArtifact(historyFile, juce::var(root)));
}

juce::String buildBenchmarkFailureReason(
    const TRuntimeValidationBenchmarkCaseReport &report) {
  juce::String failure;
  if (report.worstRuntimeStats.cpuLoadPercent >
      report.thresholds.maxCpuLoadPercent) {
    failure << "cpuLoadPercent exceeded baseline ("
            << juce::String(report.worstRuntimeStats.cpuLoadPercent, 6)
            << " > "
            << juce::String(report.thresholds.maxCpuLoadPercent, 6)
            << ")";
  }
  if (report.worstRuntimeStats.maxProcessMilliseconds >
      report.thresholds.maxProcessMilliseconds) {
    if (failure.isNotEmpty())
      failure << "; ";
    failure << "maxProcessMilliseconds exceeded baseline ("
            << juce::String(report.worstRuntimeStats.maxProcessMilliseconds, 6)
            << " > "
            << juce::String(report.thresholds.maxProcessMilliseconds, 6)
            << ")";
  }
  if (report.worstRuntimeStats.maxBuildMilliseconds >
      report.thresholds.maxBuildMilliseconds) {
    if (failure.isNotEmpty())
      failure << "; ";
    failure << "maxBuildMilliseconds exceeded baseline ("
            << juce::String(report.worstRuntimeStats.maxBuildMilliseconds, 6)
            << " > "
            << juce::String(report.thresholds.maxBuildMilliseconds, 6)
            << ")";
  }
  return failure;
}

juce::String buildBenchmarkCaseSummaryText(
    const TRuntimeValidationBenchmarkCaseReport &report) {
  juce::String summary;
  summary << "graphId=" << report.graphId << "\r\n";
  summary << "stimulusId=" << report.stimulusId << "\r\n";
  summary << "profileId=" << report.profileId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "iterationCount=" << report.iterationCount << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalRenderedSamples=" << report.totalRenderedSamples << "\r\n";
  summary << "totalRenderedBlocks=" << report.totalRenderedBlocks << "\r\n";
  summary << "thresholdCpuLoadPercent="
          << juce::String(report.thresholds.maxCpuLoadPercent, 6) << "\r\n";
  summary << "thresholdMaxProcessMilliseconds="
          << juce::String(report.thresholds.maxProcessMilliseconds, 6)
          << "\r\n";
  summary << "thresholdMaxBuildMilliseconds="
          << juce::String(report.thresholds.maxBuildMilliseconds, 6)
          << "\r\n";
  summary << "worstCpuLoadPercent="
          << juce::String(report.worstRuntimeStats.cpuLoadPercent, 6)
          << "\r\n";
  summary << "worstMaxProcessMilliseconds="
          << juce::String(report.worstRuntimeStats.maxProcessMilliseconds, 6)
          << "\r\n";
  summary << "worstMaxBuildMilliseconds="
          << juce::String(report.worstRuntimeStats.maxBuildMilliseconds, 6)
          << "\r\n";
  if (report.failureReason.isNotEmpty())
    summary << "failureReason=" << report.failureReason << "\r\n";
  return summary;
}

juce::var makeBenchmarkCaseArtifactBundle(
    const juce::File &artifactDirectory,
    const TRuntimeValidationBenchmarkCaseReport &report) {
  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry("benchmarkCaseSummary", artifactDirectory,
                                  artifactDirectory.getChildFile("case-summary.txt")));

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope", "benchmark-case");
  root->setProperty("graphId", report.graphId);
  root->setProperty("stimulusId", report.stimulusId);
  root->setProperty("profileId", report.profileId);
  root->setProperty("passed", report.passed);
  root->setProperty("iterationCount", report.iterationCount);
  root->setProperty("totalRenderedSamples", report.totalRenderedSamples);
  root->setProperty("totalRenderedBlocks", report.totalRenderedBlocks);
  root->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  root->setProperty("thresholdCpuLoadPercent", report.thresholds.maxCpuLoadPercent);
  root->setProperty("thresholdMaxProcessMilliseconds",
                    report.thresholds.maxProcessMilliseconds);
  root->setProperty("thresholdMaxBuildMilliseconds",
                    report.thresholds.maxBuildMilliseconds);
  root->setProperty("worstCpuLoadPercent", report.worstRuntimeStats.cpuLoadPercent);
  root->setProperty("worstMaxProcessMilliseconds",
                    report.worstRuntimeStats.maxProcessMilliseconds);
  root->setProperty("worstMaxBuildMilliseconds",
                    report.worstRuntimeStats.maxBuildMilliseconds);
  if (report.failureReason.isNotEmpty())
    root->setProperty("failureReason", report.failureReason);
  root->setProperty("files", juce::var(files));
  return juce::var(root);
}

void finalizeBenchmarkCaseArtifacts(
    const juce::File &artifactDirectory,
    const TRuntimeValidationBenchmarkCaseReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("case-summary.txt"),
      buildBenchmarkCaseSummaryText(report)));
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      makeBenchmarkCaseArtifactBundle(artifactDirectory, report)));
}

juce::String buildBenchmarkSuiteSummaryText(
    const TRuntimeValidationBenchmarkSuiteReport &report) {
  juce::String summary;
  summary << "suiteId=" << report.suiteId << "\r\n";
  summary << "passed=" << (report.passed ? "true" : "false") << "\r\n";
  summary << "iterationCount=" << report.iterationCount << "\r\n";
  summary << "artifactDirectory=" << report.artifactDirectory << "\r\n";
  summary << "totalCaseCount=" << report.totalCaseCount << "\r\n";
  summary << "passedCaseCount=" << report.passedCaseCount << "\r\n";
  summary << "failedCaseCount=" << report.failedCaseCount << "\r\n\r\n";
  for (const auto &caseReport : report.caseReports) {
    summary << "case=" << caseReport.graphId << "/" << caseReport.stimulusId
            << "/" << caseReport.profileId << "\r\n";
    summary << "passed=" << (caseReport.passed ? "true" : "false")
            << "\r\n";
    summary << "artifactDirectory=" << caseReport.artifactDirectory << "\r\n";
    summary << "worstCpuLoadPercent="
            << juce::String(caseReport.worstRuntimeStats.cpuLoadPercent, 6)
            << "\r\n";
    summary << "worstMaxProcessMilliseconds="
            << juce::String(caseReport.worstRuntimeStats.maxProcessMilliseconds, 6)
            << "\r\n";
    summary << "worstMaxBuildMilliseconds="
            << juce::String(caseReport.worstRuntimeStats.maxBuildMilliseconds, 6)
            << "\r\n";
    if (caseReport.failureReason.isNotEmpty())
      summary << "failureReason=" << caseReport.failureReason << "\r\n";
    summary << "\r\n";
  }
  return summary;
}

juce::var makeBenchmarkSuiteArtifactBundle(
    const juce::File &artifactDirectory,
    const TRuntimeValidationBenchmarkSuiteReport &report) {
  juce::Array<juce::var> files;
  files.add(makeArtifactFileEntry("benchmarkSummary", artifactDirectory,
                                  artifactDirectory.getChildFile("benchmark-summary.txt")));
  files.add(makeArtifactFileEntry("benchmarkHistory", artifactDirectory,
                                  makeBenchmarkSuiteHistoryFile(report.suiteId)));

  juce::Array<juce::var> cases;
  for (const auto &caseReport : report.caseReports) {
    auto *entry = new juce::DynamicObject();
    entry->setProperty("graphId", caseReport.graphId);
    entry->setProperty("stimulusId", caseReport.stimulusId);
    entry->setProperty("profileId", caseReport.profileId);
    entry->setProperty("passed", caseReport.passed);
    entry->setProperty("iterationCount", caseReport.iterationCount);
    entry->setProperty("artifactDirectory", caseReport.artifactDirectory);
    if (caseReport.artifactDirectory.isNotEmpty()) {
      const auto caseDir = juce::File(caseReport.artifactDirectory);
      entry->setProperty("relativeArtifactDirectory",
                         relativeArtifactPath(artifactDirectory, caseDir));
      entry->setProperty(
          "bundleRelativePath",
          relativeArtifactPath(
              artifactDirectory,
              caseDir.getChildFile("artifact-bundle.json")));
    }
    if (caseReport.failureReason.isNotEmpty())
      entry->setProperty("failureReason", caseReport.failureReason);
    cases.add(juce::var(entry));
  }

  auto *root = new juce::DynamicObject();
  root->setProperty("kind", "teul-verification-artifact-bundle");
  root->setProperty("scope", "benchmark-suite");
  root->setProperty("suiteId", report.suiteId);
  root->setProperty("passed", report.passed);
  root->setProperty("iterationCount", report.iterationCount);
  root->setProperty("artifactDirectory", artifactDirectory.getFullPathName());
  root->setProperty("totalCaseCount", report.totalCaseCount);
  root->setProperty("passedCaseCount", report.passedCaseCount);
  root->setProperty("failedCaseCount", report.failedCaseCount);
  root->setProperty("files", juce::var(files));
  root->setProperty("cases", juce::var(cases));
  return juce::var(root);
}

void finalizeBenchmarkSuiteArtifacts(
    const juce::File &artifactDirectory,
    const TRuntimeValidationBenchmarkSuiteReport &report) {
  juce::ignoreUnused(artifactDirectory.createDirectory());
  juce::ignoreUnused(writeTextArtifact(
      artifactDirectory.getChildFile("benchmark-summary.txt"),
      buildBenchmarkSuiteSummaryText(report)));
  appendBenchmarkHistory(report);
  juce::ignoreUnused(writeJsonArtifact(
      artifactDirectory.getChildFile("artifact-bundle.json"),
      makeBenchmarkSuiteArtifactBundle(artifactDirectory, report)));
}

} // namespace

std::vector<TRuntimeValidationGraphFixture>
TRuntimeValidator::makeRepresentativeGraphSet(const TNodeRegistry &registry) {
  std::vector<TRuntimeValidationGraphFixture> fixtures;
  fixtures.push_back(
      {"G1", "Tone Path", makeRepresentativeGraphG1TonePath(registry)});
  fixtures.push_back(
      {"G2", "Filter Sweep", makeRepresentativeGraphG2FilterSweep(registry)});
  fixtures.push_back(
      {"G3", "Stereo Motion", makeRepresentativeGraphG3StereoMotion(registry)});
  fixtures.push_back(
      {"G4", "MIDI Voice", makeRepresentativeGraphG4MidiVoice(registry)});
  fixtures.push_back(
      {"G5", "Time Tail", makeRepresentativeGraphG5TimeTail(registry)});
  return fixtures;
}
TRuntimeValidationRenderProfile TRuntimeValidator::makePrimaryRenderProfile() {
  return {"primary", 48000.0, 128, 2, 2.0};
}

TRuntimeValidationRenderProfile
TRuntimeValidator::makeSecondaryRenderProfile() {
  return {"secondary", 48000.0, 480, 2, 2.0};
}

TRuntimeValidationRenderProfile
TRuntimeValidator::makeExtendedRenderProfile() {
  return {"extended", 96000.0, 128, 2, 2.0};
}

TRuntimeValidationStimulusSpec TRuntimeValidator::makeStaticRenderStimulus() {
  return {"S1", "Static Render", TRuntimeValidationStimulusKind::StaticRender,
          {}, {}};
}

TRuntimeValidationStimulusSpec TRuntimeValidator::makeStepAutomationStimulus(
    const juce::String &nodeLabel, const juce::String &paramKey,
    float startValue, float endValue, double stepIntervalSeconds) {
  TRuntimeValidationStimulusSpec stimulus;
  stimulus.stimulusId = "S2";
  stimulus.displayName = "Step Automation";
  stimulus.kind = TRuntimeValidationStimulusKind::StepAutomation;
  stimulus.automationLanes.push_back(
      {nodeLabel, paramKey, TRuntimeValidationAutomationMode::Step,
       startValue, endValue, stepIntervalSeconds});
  return stimulus;
}

TRuntimeValidationStimulusSpec TRuntimeValidator::makeSweepAutomationStimulus(
    const juce::String &nodeLabel, const juce::String &paramKey,
    float startValue, float endValue) {
  TRuntimeValidationStimulusSpec stimulus;
  stimulus.stimulusId = "S3";
  stimulus.displayName = "Sweep Automation";
  stimulus.kind = TRuntimeValidationStimulusKind::SweepAutomation;
  stimulus.automationLanes.push_back(
      {nodeLabel, paramKey, TRuntimeValidationAutomationMode::Linear,
       startValue, endValue, 0.25});
  return stimulus;
}

TRuntimeValidationStimulusSpec TRuntimeValidator::makeMidiPhraseStimulus() {
  TRuntimeValidationStimulusSpec stimulus;
  stimulus.stimulusId = "S4";
  stimulus.displayName = "MIDI Phrase";
  stimulus.kind = TRuntimeValidationStimulusKind::MidiPhrase;
  const double sampleRate = 48000.0;
  auto sampleOffsetForSeconds = [sampleRate](double seconds) {
    return juce::roundToInt(seconds * sampleRate);
  };
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(0.00),
                                 juce::MidiMessage::noteOn(
                                     1, 60, (juce::uint8)96)});
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(0.35),
                                 juce::MidiMessage::noteOff(1, 60)});
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(0.55),
                                 juce::MidiMessage::noteOn(
                                     1, 64, (juce::uint8)110)});
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(0.95),
                                 juce::MidiMessage::noteOff(1, 64)});
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(1.15),
                                 juce::MidiMessage::noteOn(
                                     1, 67, (juce::uint8)100)});
  stimulus.midiEvents.push_back({sampleOffsetForSeconds(1.65),
                                 juce::MidiMessage::noteOff(1, 67)});
  return stimulus;
}
bool TRuntimeValidator::renderDocumentWithStimulus(
    const TNodeRegistry &registry, const TTeulDocument &document,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus,
    TRuntimeValidationRenderResult &resultOut,
    juce::String *errorMessageOut) {
  if (profile.sampleRate <= 0.0 || profile.blockSize <= 0 ||
      profile.outputChannels <= 0 || profile.durationSeconds <= 0.0) {
    writeError(errorMessageOut, "Invalid verification render profile.");
    return false;
  }

  std::vector<std::pair<NodeId, TRuntimeValidationAutomationLane>> resolvedLanes;
  resolvedLanes.reserve(stimulus.automationLanes.size());
  for (const auto &lane : stimulus.automationLanes) {
    const NodeId nodeId = findNodeIdByLabel(document, lane.nodeLabel);
    if (nodeId == kInvalidNodeId) {
      writeError(errorMessageOut,
                 "Verification stimulus references a missing node label: " +
                     lane.nodeLabel);
      return false;
    }
    resolvedLanes.push_back({nodeId, lane});
  }

  std::vector<TRuntimeValidationMidiEvent> midiEvents = stimulus.midiEvents;
  std::sort(midiEvents.begin(), midiEvents.end(),
            [](const auto &lhs, const auto &rhs) {
              return lhs.sampleOffset < rhs.sampleOffset;
            });

  TTeulRuntime runtime(&registry);
  if (!runtime.buildGraph(document)) {
    writeError(errorMessageOut, "Failed to build verification graph.");
    return false;
  }

  runtime.setCurrentChannelLayout(0, profile.outputChannels);
  runtime.prepareToPlay(profile.sampleRate, profile.blockSize);

  const int totalSamples = juce::jmax(
      1, juce::roundToInt(profile.durationSeconds * profile.sampleRate));
  resultOut.graphName = document.meta.name;
  resultOut.stimulusId = stimulus.stimulusId;
  resultOut.profileId = profile.profileId;
  resultOut.totalSamples = totalSamples;
  resultOut.audioBuffer.setSize(profile.outputChannels, totalSamples, false,
                                false, true);
  resultOut.audioBuffer.clear();
  resultOut.renderedBlockCount = 0;

  std::size_t midiEventIndex = 0;
  for (int blockStart = 0; blockStart < totalSamples;
       blockStart += profile.blockSize) {
    const int blockSamples =
        juce::jmin(profile.blockSize, totalSamples - blockStart);
    for (const auto &resolvedLane : resolvedLanes) {
      const float value = valueForLaneAtSample(
          resolvedLane.second, blockStart, totalSamples, profile.sampleRate);
      runtime.queueParameterChange(resolvedLane.first,
                                   resolvedLane.second.paramKey, value);
    }

    juce::AudioBuffer<float> blockBuffer(profile.outputChannels, blockSamples);
    juce::MidiBuffer midiBuffer;
    while (midiEventIndex < midiEvents.size() &&
           midiEvents[midiEventIndex].sampleOffset <
               (blockStart + blockSamples)) {
      const auto &event = midiEvents[midiEventIndex];
      if (event.sampleOffset >= blockStart)
        midiBuffer.addEvent(event.message, event.sampleOffset - blockStart);
      ++midiEventIndex;
    }

    runtime.processBlock(blockBuffer, midiBuffer);
    for (int channel = 0; channel < profile.outputChannels; ++channel) {
      resultOut.audioBuffer.copyFrom(channel, blockStart, blockBuffer, channel,
                                     0, blockSamples);
    }
    ++resultOut.renderedBlockCount;
  }

  resultOut.runtimeStats = runtime.getRuntimeStats();
  return true;
}

bool TRuntimeValidator::runEditableExportRoundTripParity(
    const TNodeRegistry &registry,
    const TRuntimeValidationGraphFixture &fixture,
    const TRuntimeValidationRenderProfile &profile,
    const TRuntimeValidationStimulusSpec &stimulus,
    TRuntimeValidationParityReport &reportOut, float maxAbsoluteTolerance,
    double rmsTolerance) {
  reportOut = {};
  reportOut.graphId = fixture.fixtureId;
  reportOut.stimulusId = stimulus.stimulusId;
  reportOut.profileId = profile.profileId;
  reportOut.modeId = "editable-roundtrip";

  const auto artifactDirectory =
      makeCaseArtifactDirectory(fixture, profile, stimulus);
  reportOut.artifactDirectory = artifactDirectory.getFullPathName();
  juce::ignoreUnused(artifactDirectory.deleteRecursively());
  juce::ignoreUnused(artifactDirectory.createDirectory());

  TRuntimeValidationRenderResult sourceRender;
  juce::String sourceRenderError;
  if (!renderDocumentWithStimulus(registry, fixture.document, profile, stimulus,
                                  sourceRender, &sourceRenderError)) {
    reportOut.failureReason =
        "Source runtime render failed: " + sourceRenderError;
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }

  // Teul2 자립화를 위해 레거시 Export 테스트 로직 일시 중단
  reportOut.failureReason = "Legacy export parity test is disabled in Teul2-only mode.";
  finalizeCaseArtifacts(artifactDirectory, reportOut);
  return false;

  /*
  TGraphDocument exportDocument;
  if (!TGraphCompiler::compileLegacyDocument(exportDocument, fixture.document)) {
    reportOut.failureReason =
        "EditableGraph export failed: Teul2 document compile to legacy graph failed.";
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }

  TExportOptions options;
  options.mode = TExportMode::EditableGraph;
  options.dryRunOnly = false;
  options.outputDirectory = artifactDirectory.getChildFile("export-package");
  options.projectRootDirectory = juce::File::getCurrentWorkingDirectory();

  TExportReport exportReport;
  const auto exportResult =
      TExporter::exportToDirectory(exportDocument, registry, options,
                                   exportReport);
  reportOut.exportReport = exportReport;
  reportOut.exportWarningCount = exportReport.warningCount();
  reportOut.exportErrorCount = exportReport.errorCount();
  if (exportResult.failed()) {
    reportOut.failureReason =
        "EditableGraph export failed: " + exportResult.getErrorMessage();
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }

  TTeulDocument importedDocument;
  const auto importResult =
      TDocumentStore::importEditableGraphPackage(options.outputDirectory,
                                                 importedDocument);
  if (importResult.failed()) {
    reportOut.failureReason =
        "EditableGraph import failed: " + importResult.getErrorMessage();
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }
  reportOut.importedDocumentLoaded = true;

  TRuntimeValidationRenderResult importedRender;
  juce::String importedRenderError;
  if (!renderDocumentWithStimulus(registry, importedDocument, profile,
                                  stimulus, importedRender,
                                  &importedRenderError)) {
    reportOut.failureReason =
        "Imported runtime render failed: " + importedRenderError;
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }

  const int channels = juce::jmin(sourceRender.audioBuffer.getNumChannels(),
                                  importedRender.audioBuffer.getNumChannels());
  const int samples = juce::jmin(sourceRender.audioBuffer.getNumSamples(),
                                 importedRender.audioBuffer.getNumSamples());
  reportOut.totalSamples = samples;
  reportOut.comparedChannels = channels;
  if (channels <= 0 || samples <= 0) {
    reportOut.failureReason =
        "Parity render produced an empty audio buffer.";
    finalizeCaseArtifacts(artifactDirectory, reportOut);
    return false;
  }

  double squaredErrorSum = 0.0;
  int comparedSampleCount = 0;
  for (int channel = 0; channel < channels; ++channel) {
    const float *lhs = sourceRender.audioBuffer.getReadPointer(channel);
    const float *rhs = importedRender.audioBuffer.getReadPointer(channel);
    for (int sampleIndex = 0; sampleIndex < samples; ++sampleIndex) {
      const float a = normalizeSample(lhs[sampleIndex]);
      const float b = normalizeSample(rhs[sampleIndex]);
      if (!std::isfinite(a) || !std::isfinite(b)) {
        reportOut.firstMismatchChannel = channel;
        reportOut.firstMismatchSample = sampleIndex;
        reportOut.failureReason =
            "Parity compare encountered NaN or Inf.";
        finalizeCaseArtifacts(artifactDirectory, reportOut);
        return false;
      }

      const double error = static_cast<double>(a) - static_cast<double>(b);
      const float absError = static_cast<float>(std::abs(error));
      reportOut.maxAbsoluteError = juce::jmax(reportOut.maxAbsoluteError,
                                              absError);
      squaredErrorSum += error * error;
      ++comparedSampleCount;
      if (reportOut.firstMismatchSample < 0 &&
          absError > maxAbsoluteTolerance) {
        reportOut.firstMismatchChannel = channel;
        reportOut.firstMismatchSample = sampleIndex;
      }
    }
  }

  reportOut.rmsError =
      comparedSampleCount > 0
          ? std::sqrt(squaredErrorSum /
                      static_cast<double>(comparedSampleCount))
          : 0.0;
  reportOut.passed = reportOut.maxAbsoluteError <= maxAbsoluteTolerance &&
                     reportOut.rmsError <= rmsTolerance;
  finalizeCaseArtifacts(artifactDirectory, reportOut);
  return reportOut.passed;
  */
}

bool TRuntimeValidator::runInitialG1StaticParitySmoke(
    const TNodeRegistry &registry,
    TRuntimeValidationParityReport &reportOut) {
  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &fixture : fixtures) {
    if (fixture.fixtureId == "G1") {
      return runEditableExportRoundTripParity(
          registry, fixture, makePrimaryRenderProfile(),
          makeStaticRenderStimulus(), reportOut);
    }
  }
  reportOut = {};
  reportOut.graphId = "G1";
  reportOut.stimulusId = "S1";
  reportOut.profileId = "primary";
  reportOut.modeId = "editable-roundtrip";
  reportOut.failureReason = "G1 fixture was not found.";
  return false;
}

bool TRuntimeValidator::runRepresentativePrimaryParityMatrix(
    const TNodeRegistry &registry,
    TRuntimeValidationParitySuiteReport &reportOut) {
  reportOut = {};
  reportOut.suiteId = "representative-primary";
  const auto artifactDirectory = juce::File::getCurrentWorkingDirectory()
                                     .getChildFile("Builds")
                                     .getChildFile("TeulVerification")
                                     .getChildFile("EditableRoundTrip")
                                     .getChildFile(
                                         "RepresentativeMatrix_primary");
  reportOut.artifactDirectory = artifactDirectory.getFullPathName();
  juce::ignoreUnused(artifactDirectory.deleteRecursively());
  juce::ignoreUnused(artifactDirectory.createDirectory());

  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &caseSpec : makeRepresentativePrimaryCases()) {
    TRuntimeValidationParityReport caseReport;
    const auto *fixture = findFixtureById(fixtures, caseSpec.fixtureId);
    if (fixture == nullptr) {
      caseReport.graphId = caseSpec.fixtureId;
      caseReport.stimulusId = caseSpec.stimulus.stimulusId;
      caseReport.profileId = caseSpec.profile.profileId;
      caseReport.modeId = "editable-roundtrip";
      caseReport.failureReason =
          "Representative parity matrix fixture was not found.";
      caseReport.passed = false;
    } else {
      caseReport.passed = runEditableExportRoundTripParity(
          registry, *fixture, caseSpec.profile, caseSpec.stimulus,
          caseReport);
    }

    ++reportOut.totalCaseCount;
    if (caseReport.passed)
      ++reportOut.passedCaseCount;
    else
      ++reportOut.failedCaseCount;
    reportOut.caseReports.push_back(caseReport);
  }

  reportOut.passed =
      reportOut.totalCaseCount > 0 && reportOut.failedCaseCount == 0;
  finalizeSuiteArtifacts(artifactDirectory, reportOut);
  return reportOut.passed;
}
bool TRuntimeValidator::runRepresentativeGoldenAudioRecord(
    const TNodeRegistry &registry,
    TRuntimeValidationGoldenAudioSuiteReport &reportOut) {
  reportOut = {};
  reportOut.suiteId = "representative-primary";
  reportOut.modeId = "record";
  const auto suiteDirectory = baselineSuiteDirectory();
  reportOut.baselineDirectory = suiteDirectory.getFullPathName();
  juce::ignoreUnused(suiteDirectory.createDirectory());

  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &caseSpec : makeRepresentativePrimaryCases()) {
    TRuntimeValidationGoldenAudioReport caseReport;
    caseReport.graphId = caseSpec.fixtureId;
    caseReport.stimulusId = caseSpec.stimulus.stimulusId;
    caseReport.profileId = caseSpec.profile.profileId;
    caseReport.modeId = "record";

    const auto *fixture = findFixtureById(fixtures, caseSpec.fixtureId);
    if (fixture == nullptr) {
      caseReport.failureReason =
          "Representative golden fixture was not found.";
    } else {
      const auto caseDirectory = makeGoldenCaseDirectory(
          suiteDirectory, *fixture, caseSpec.profile, caseSpec.stimulus);
      juce::ignoreUnused(caseDirectory.deleteRecursively());
      juce::ignoreUnused(caseDirectory.createDirectory());
      caseReport.baselineDirectory = caseDirectory.getFullPathName();

      TRuntimeValidationRenderResult renderResult;
      juce::String renderError;
      if (!renderDocumentWithStimulus(registry, fixture->document,
                                      caseSpec.profile, caseSpec.stimulus,
                                      renderResult, &renderError)) {
        caseReport.failureReason =
            "Golden audio record render failed: " + renderError;
      } else {
        caseReport.totalSamples = renderResult.totalSamples;
        const auto waveFile = caseDirectory.getChildFile("golden-output.wav");
        juce::String writeErrorMessage;
        if (!writeWaveFile(waveFile, renderResult.audioBuffer,
                           caseSpec.profile.sampleRate,
                           &writeErrorMessage)) {
          caseReport.failureReason = writeErrorMessage;
        } else {
          juce::ignoreUnused(writeJsonArtifact(
              caseDirectory.getChildFile("golden-metadata.json"),
              makeGoldenMetadata(*fixture, caseSpec.profile, caseSpec.stimulus,
                                 renderResult, caseDirectory)));
          caseReport.baselineExists = true;
          caseReport.passed = true;
        }
      }

      finalizeGoldenRecordCaseArtifacts(caseDirectory, caseReport,
                                        caseSpec.profile);
    }

    ++reportOut.totalCaseCount;
    if (caseReport.passed)
      ++reportOut.passedCaseCount;
    else
      ++reportOut.failedCaseCount;
    reportOut.caseReports.push_back(caseReport);
  }

  reportOut.passed =
      reportOut.totalCaseCount > 0 && reportOut.failedCaseCount == 0;
  finalizeGoldenSuiteArtifacts(suiteDirectory, reportOut, false);
  return reportOut.passed;
}

bool TRuntimeValidator::runRepresentativeGoldenAudioVerify(
    const TNodeRegistry &registry,
    TRuntimeValidationGoldenAudioSuiteReport &reportOut,
    float maxAbsoluteTolerance,
    double rmsTolerance) {
  reportOut = {};
  reportOut.suiteId = "representative-primary";
  reportOut.modeId = "verify";
  const auto baselineDirectory = baselineSuiteDirectory();
  const auto artifactDirectory = verifySuiteArtifactDirectory();
  reportOut.baselineDirectory = baselineDirectory.getFullPathName();
  reportOut.artifactDirectory = artifactDirectory.getFullPathName();
  juce::ignoreUnused(artifactDirectory.deleteRecursively());
  juce::ignoreUnused(artifactDirectory.createDirectory());

  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &caseSpec : makeRepresentativePrimaryCases()) {
    TRuntimeValidationGoldenAudioReport caseReport;
    caseReport.graphId = caseSpec.fixtureId;
    caseReport.stimulusId = caseSpec.stimulus.stimulusId;
    caseReport.profileId = caseSpec.profile.profileId;
    caseReport.modeId = "verify";

    const auto *fixture = findFixtureById(fixtures, caseSpec.fixtureId);
    if (fixture == nullptr) {
      caseReport.failureReason =
          "Representative golden fixture was not found.";
    } else {
      const auto caseBaselineDirectory = makeGoldenCaseDirectory(
          baselineDirectory, *fixture, caseSpec.profile, caseSpec.stimulus);
      const auto caseArtifactDirectory = makeGoldenCaseDirectory(
          artifactDirectory, *fixture, caseSpec.profile, caseSpec.stimulus);
      juce::ignoreUnused(caseArtifactDirectory.createDirectory());
      caseReport.baselineDirectory = caseBaselineDirectory.getFullPathName();
      caseReport.artifactDirectory = caseArtifactDirectory.getFullPathName();

      const auto baselineWaveFile =
          caseBaselineDirectory.getChildFile("golden-output.wav");
      caseReport.baselineExists = baselineWaveFile.existsAsFile();
      if (!caseReport.baselineExists) {
        caseReport.failureReason = "Golden baseline WAV file is missing.";
      } else {
        TRuntimeValidationRenderResult renderResult;
        juce::String renderError;
        if (!renderDocumentWithStimulus(registry, fixture->document,
                                        caseSpec.profile, caseSpec.stimulus,
                                        renderResult, &renderError)) {
          caseReport.failureReason =
              "Golden audio verify render failed: " + renderError;
        } else {
          juce::AudioBuffer<float> goldenBuffer;
          double goldenSampleRate = 0.0;
          juce::String readErrorMessage;
          if (!readWaveFile(baselineWaveFile, goldenBuffer, goldenSampleRate,
                            &readErrorMessage)) {
            caseReport.failureReason = readErrorMessage;
          } else if (std::abs(goldenSampleRate - caseSpec.profile.sampleRate) >
                     0.01) {
            caseReport.failureReason =
                "Golden baseline sample rate does not match the verification profile.";
          } else {
            compareWithGolden(renderResult, goldenBuffer, caseReport,
                              maxAbsoluteTolerance, rmsTolerance);
          }
        }
      }

      finalizeGoldenVerifyCaseArtifacts(caseArtifactDirectory, caseReport);
    }

    ++reportOut.totalCaseCount;
    if (caseReport.passed)
      ++reportOut.passedCaseCount;
    else
      ++reportOut.failedCaseCount;
    reportOut.caseReports.push_back(caseReport);
  }

  reportOut.passed =
      reportOut.totalCaseCount > 0 && reportOut.failedCaseCount == 0;
  finalizeGoldenSuiteArtifacts(artifactDirectory, reportOut, true);
  return reportOut.passed;
}

bool TRuntimeValidator::runRepresentativeStressSoakSuite(
    const TNodeRegistry &registry,
    TRuntimeValidationStressSuiteReport &reportOut,
    int iterationCount) {
  reportOut = {};
  reportOut.suiteId = "representative-stress-primary";
  reportOut.iterationCount = juce::jmax(1, iterationCount);
  const auto suiteArtifactDirectory =
      makeStressSuiteArtifactDirectory(reportOut.suiteId);
  reportOut.artifactDirectory = suiteArtifactDirectory.getFullPathName();
  juce::ignoreUnused(suiteArtifactDirectory.deleteRecursively());
  juce::ignoreUnused(suiteArtifactDirectory.createDirectory());

  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &caseSpec : makeRepresentativePrimaryCases()) {
    TRuntimeValidationStressCaseReport caseReport;
    caseReport.graphId = caseSpec.fixtureId;
    caseReport.stimulusId = caseSpec.stimulus.stimulusId;
    caseReport.profileId = caseSpec.profile.profileId;
    caseReport.iterationCount = reportOut.iterationCount;

    const auto *fixture = findFixtureById(fixtures, caseSpec.fixtureId);
    if (fixture == nullptr) {
      caseReport.failureReason =
          "Representative stress fixture was not found.";
    } else {
      const auto caseArtifactDirectory = makeStressCaseArtifactDirectory(
          suiteArtifactDirectory, *fixture, caseSpec.profile,
          caseSpec.stimulus);
      caseReport.artifactDirectory = caseArtifactDirectory.getFullPathName();
      juce::ignoreUnused(caseArtifactDirectory.deleteRecursively());
      juce::ignoreUnused(caseArtifactDirectory.createDirectory());

      for (int iteration = 0; iteration < reportOut.iterationCount;
           ++iteration) {
        TRuntimeValidationRenderResult renderResult;
        juce::String renderError;
        if (!renderDocumentWithStimulus(registry, fixture->document,
                                        caseSpec.profile, caseSpec.stimulus,
                                        renderResult, &renderError)) {
          caseReport.failureReason =
              "Stress render failed at iteration " +
              juce::String(iteration + 1) + ": " + renderError;
          break;
        }
        if (renderResult.audioBuffer.getNumChannels() <= 0 ||
            renderResult.audioBuffer.getNumSamples() <= 0) {
          caseReport.failureReason =
              "Stress render produced an empty audio buffer at iteration " +
              juce::String(iteration + 1) + ".";
          break;
        }

        bool hasFiniteAudio = true;
        for (int channel = 0; channel < renderResult.audioBuffer.getNumChannels() &&
                               hasFiniteAudio;
             ++channel) {
          const auto *samples = renderResult.audioBuffer.getReadPointer(channel);
          for (int sampleIndex = 0;
               sampleIndex < renderResult.audioBuffer.getNumSamples();
               ++sampleIndex) {
            if (!std::isfinite(samples[sampleIndex])) {
              hasFiniteAudio = false;
              break;
            }
          }
        }
        if (!hasFiniteAudio) {
          caseReport.failureReason =
              "Stress render produced NaN or Inf samples at iteration " +
              juce::String(iteration + 1) + ".";
          break;
        }
        if (!isFiniteRuntimeStats(renderResult.runtimeStats)) {
          caseReport.failureReason =
              "Stress render produced non-finite runtime stats at iteration " +
              juce::String(iteration + 1) + ".";
          break;
        }

        caseReport.totalRenderedSamples += renderResult.totalSamples;
        caseReport.totalRenderedBlocks += renderResult.renderedBlockCount;
        caseReport.worstRuntimeStats =
            (iteration == 0)
                ? renderResult.runtimeStats
                : maxRuntimeStats(caseReport.worstRuntimeStats,
                                  renderResult.runtimeStats);
      }

      caseReport.passed = caseReport.failureReason.isEmpty();
      finalizeStressCaseArtifacts(caseArtifactDirectory, caseReport);
    }

    ++reportOut.totalCaseCount;
    if (caseReport.passed)
      ++reportOut.passedCaseCount;
    else
      ++reportOut.failedCaseCount;
    reportOut.caseReports.push_back(caseReport);
  }

  reportOut.passed =
      reportOut.totalCaseCount > 0 && reportOut.failedCaseCount == 0;
  finalizeStressSuiteArtifacts(suiteArtifactDirectory, reportOut);
  return reportOut.passed;
}

bool TRuntimeValidator::runRepresentativeBenchmarkGate(
    const TNodeRegistry &registry,
    TRuntimeValidationBenchmarkSuiteReport &reportOut,
    int iterationCount) {
  reportOut = {};
  reportOut.suiteId = "representative-benchmark-primary";
  reportOut.iterationCount = juce::jmax(1, iterationCount);
  const auto suiteArtifactDirectory =
      makeBenchmarkSuiteArtifactDirectory(reportOut.suiteId);
  reportOut.artifactDirectory = suiteArtifactDirectory.getFullPathName();
  juce::ignoreUnused(suiteArtifactDirectory.deleteRecursively());
  juce::ignoreUnused(suiteArtifactDirectory.createDirectory());

  const auto fixtures = makeRepresentativeGraphSet(registry);
  for (const auto &caseSpec : makeRepresentativeBenchmarkCases()) {
    TRuntimeValidationBenchmarkCaseReport caseReport;
    caseReport.graphId = caseSpec.fixtureId;
    caseReport.stimulusId = caseSpec.stimulus.stimulusId;
    caseReport.profileId = caseSpec.profile.profileId;
    caseReport.iterationCount = reportOut.iterationCount;
    caseReport.thresholds = caseSpec.thresholds;

    const auto *fixture = findFixtureById(fixtures, caseSpec.fixtureId);
    if (fixture == nullptr) {
      caseReport.failureReason =
          "Representative benchmark fixture was not found.";
    } else {
      const auto caseArtifactDirectory = makeBenchmarkCaseArtifactDirectory(
          suiteArtifactDirectory, *fixture, caseSpec.profile,
          caseSpec.stimulus);
      caseReport.artifactDirectory = caseArtifactDirectory.getFullPathName();
      juce::ignoreUnused(caseArtifactDirectory.deleteRecursively());
      juce::ignoreUnused(caseArtifactDirectory.createDirectory());

      for (int iteration = 0; iteration < reportOut.iterationCount;
           ++iteration) {
        TRuntimeValidationRenderResult renderResult;
        juce::String renderError;
        if (!renderDocumentWithStimulus(registry, fixture->document,
                                        caseSpec.profile, caseSpec.stimulus,
                                        renderResult, &renderError)) {
          caseReport.failureReason =
              "Benchmark render failed at iteration " +
              juce::String(iteration + 1) + ": " + renderError;
          break;
        }
        if (renderResult.audioBuffer.getNumChannels() <= 0 ||
            renderResult.audioBuffer.getNumSamples() <= 0) {
          caseReport.failureReason =
              "Benchmark render produced an empty audio buffer at iteration " +
              juce::String(iteration + 1) + ".";
          break;
        }
        if (!isFiniteRuntimeStats(renderResult.runtimeStats)) {
          caseReport.failureReason =
              "Benchmark render produced non-finite runtime stats at iteration " +
              juce::String(iteration + 1) + ".";
          break;
        }

        caseReport.totalRenderedSamples += renderResult.totalSamples;
        caseReport.totalRenderedBlocks += renderResult.renderedBlockCount;
        caseReport.worstRuntimeStats =
            (iteration == 0)
                ? renderResult.runtimeStats
                : maxRuntimeStats(caseReport.worstRuntimeStats,
                                  renderResult.runtimeStats);
      }

      if (caseReport.failureReason.isEmpty())
        caseReport.failureReason = buildBenchmarkFailureReason(caseReport);
      caseReport.passed = caseReport.failureReason.isEmpty();
      finalizeBenchmarkCaseArtifacts(caseArtifactDirectory, caseReport);
    }

    ++reportOut.totalCaseCount;
    if (caseReport.passed)
      ++reportOut.passedCaseCount;
    else
      ++reportOut.failedCaseCount;
    reportOut.caseReports.push_back(caseReport);
  }

  reportOut.passed =
      reportOut.totalCaseCount > 0 && reportOut.failedCaseCount == 0;
  finalizeBenchmarkSuiteArtifacts(suiteArtifactDirectory, reportOut);
  return reportOut.passed;
}

} // namespace Teul
